const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const Contact = require('../models/Contact');
const User = require('../models/User');
const { isLiveMongo } = require('../config/db');
const { defaultContacts, defaultUsers } = require('../data/defaultData');

// In-Memory store tables
let inMemoryContacts = [];
let inMemoryUsers = [];
let hasSeeded = false;

// Initialize in-memory or mongo seed data
const initSeedData = async () => {
  if (hasSeeded) return;

  if (isLiveMongo()) {
    try {
      const userCount = await User.countDocuments();
      if (userCount === 0) {
        console.log('[Seed] Seeding default users into MongoDB...');
        for (const u of defaultUsers) {
          const userDoc = new User(u);
          await userDoc.save();
        }
      }

      const contactCount = await Contact.countDocuments();
      if (contactCount === 0) {
        console.log('[Seed] Seeding default emergency contacts into MongoDB...');
        const adminUser = await User.findOne({ role: 'admin' });
        const contactsToInsert = defaultContacts.map((c) => ({
          ...c,
          createdBy: adminUser ? adminUser._id : undefined,
        }));
        await Contact.insertMany(contactsToInsert);
      }
      hasSeeded = true;
      console.log('✅ [Seed] MongoDB database seed verified.');
    } catch (err) {
      console.error('[Seed] Error seeding MongoDB:', err.message);
    }
  } else {
    // Seed in-memory store
    console.log('[Seed] Initializing Resilient In-Memory Data Store with default records...');
    inMemoryUsers = [];
    for (const u of defaultUsers) {
      const salt = await bcrypt.genSalt(10);
      const hashedPassword = await bcrypt.hash(u.password, salt);
      const userId = new mongoose.Types.ObjectId().toString();
      inMemoryUsers.push({
        _id: userId,
        id: userId,
        name: u.name,
        email: u.email.toLowerCase(),
        password: hashedPassword,
        role: u.role,
        phone: u.phone,
        location: u.location,
        savedContacts: [],
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      });
    }

    const adminUser = inMemoryUsers.find((u) => u.role === 'admin');
    inMemoryContacts = defaultContacts.map((c, index) => {
      const id = new mongoose.Types.ObjectId().toString();
      return {
        _id: id,
        id: id,
        ...c,
        createdBy: adminUser ? adminUser._id : null,
        createdAt: new Date(Date.now() - (10 - index) * 3600000).toISOString(),
        updatedAt: new Date().toISOString(),
      };
    });

    hasSeeded = true;
    console.log(`✅ [Seed] In-Memory store initialized with ${inMemoryContacts.length} emergency contacts and ${inMemoryUsers.length} users.`);
  }
};

// ================= CONTACTS SERVICE ================= //

const getContacts = async ({ q, service, city, priority, status, sort }) => {
  if (isLiveMongo()) {
    const filter = {};
    if (service && service !== 'All') {
      filter.service = service;
    }
    if (city && city !== 'All') {
      filter['location.city'] = new RegExp(`^${city}$`, 'i');
    }
    if (priority && priority !== 'All') {
      filter.priority = priority;
    }
    if (status && status !== 'All') {
      filter.status = status;
    }
    if (q && q.trim()) {
      const regex = new RegExp(q.trim(), 'i');
      filter.$or = [
        { name: regex },
        { service: regex },
        { phone: regex },
        { alternatePhone: regex },
        { 'location.address': regex },
        { 'location.city': regex },
        { description: regex },
      ];
    }

    let query = Contact.find(filter).populate('createdBy', 'name email role');
    if (sort === 'priority') {
      // Custom priority sort or name sort
      query = query.sort({ priority: 1, name: 1 });
    } else if (sort === 'name') {
      query = query.sort({ name: 1 });
    } else {
      query = query.sort({ createdAt: -1 });
    }

    return await query.exec();
  } else {
    // In-memory filter
    let results = [...inMemoryContacts];

    if (service && service !== 'All') {
      results = results.filter((c) => c.service.toLowerCase() === service.toLowerCase());
    }
    if (city && city !== 'All') {
      results = results.filter((c) => c.location.city.toLowerCase() === city.toLowerCase());
    }
    if (priority && priority !== 'All') {
      results = results.filter((c) => c.priority.toLowerCase() === priority.toLowerCase());
    }
    if (status && status !== 'All') {
      results = results.filter((c) => c.status.toLowerCase() === status.toLowerCase());
    }
    if (q && q.trim()) {
      const search = q.trim().toLowerCase();
      results = results.filter((c) => {
        return (
          c.name.toLowerCase().includes(search) ||
          c.service.toLowerCase().includes(search) ||
          c.phone.toLowerCase().includes(search) ||
          (c.alternatePhone && c.alternatePhone.toLowerCase().includes(search)) ||
          c.location.address.toLowerCase().includes(search) ||
          c.location.city.toLowerCase().includes(search) ||
          (c.description && c.description.toLowerCase().includes(search))
        );
      });
    }

    // Sort
    if (sort === 'name') {
      results.sort((a, b) => a.name.localeCompare(b.name));
    } else if (sort === 'priority') {
      const priorityWeights = { Critical: 3, High: 2, Standard: 1 };
      results.sort((a, b) => (priorityWeights[b.priority] || 0) - (priorityWeights[a.priority] || 0));
    } else {
      results.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    }

    return results;
  }
};

const getContactById = async (id) => {
  if (isLiveMongo()) {
    return await Contact.findById(id).populate('createdBy', 'name email role');
  } else {
    return inMemoryContacts.find((c) => c._id.toString() === id.toString() || c.id === id) || null;
  }
};

const createContact = async (contactData, user) => {
  if (isLiveMongo()) {
    const contact = new Contact({
      ...contactData,
      createdBy: user ? user._id : undefined,
    });
    return await contact.save();
  } else {
    const newId = new mongoose.Types.ObjectId().toString();
    const newContact = {
      _id: newId,
      id: newId,
      ...contactData,
      createdBy: user ? { _id: user._id, name: user.name, email: user.email, role: user.role } : null,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    inMemoryContacts.unshift(newContact);
    return newContact;
  }
};

const updateContact = async (id, updateData) => {
  if (isLiveMongo()) {
    return await Contact.findByIdAndUpdate(
      id,
      { ...updateData, updatedAt: new Date() },
      { new: true, runValidators: true }
    );
  } else {
    const index = inMemoryContacts.findIndex((c) => c._id.toString() === id.toString() || c.id === id);
    if (index === -1) return null;

    inMemoryContacts[index] = {
      ...inMemoryContacts[index],
      ...updateData,
      location: {
        ...inMemoryContacts[index].location,
        ...(updateData.location || {}),
      },
      updatedAt: new Date().toISOString(),
    };
    return inMemoryContacts[index];
  }
};

const deleteContact = async (id) => {
  if (isLiveMongo()) {
    return await Contact.findByIdAndDelete(id);
  } else {
    const index = inMemoryContacts.findIndex((c) => c._id.toString() === id.toString() || c.id === id);
    if (index === -1) return null;
    const removed = inMemoryContacts.splice(index, 1);
    return removed[0];
  }
};

const getStats = async () => {
  const contacts = await getContacts({});
  const total = contacts.length;

  const byService = {};
  const byPriority = { Critical: 0, High: 0, Standard: 0 };
  const cities = new Set();
  let available247Count = 0;
  let activeCount = 0;

  for (const c of contacts) {
    byService[c.service] = (byService[c.service] || 0) + 1;
    if (byPriority[c.priority] !== undefined) {
      byPriority[c.priority]++;
    }
    if (c.location && c.location.city) {
      cities.add(c.location.city);
    }
    if (c.operatingHours && c.operatingHours.includes('24/7')) {
      available247Count++;
    }
    if (c.status === 'Active') {
      activeCount++;
    }
  }

  return {
    totalContacts: total,
    activeContacts: activeCount,
    available247: available247Count,
    totalCities: cities.size,
    uniqueCities: Array.from(cities),
    byService,
    byPriority,
  };
};

const resetAndSeedContacts = async () => {
  hasSeeded = false;
  if (isLiveMongo()) {
    await Contact.deleteMany({});
  }
  await initSeedData();
  return await getContacts({});
};

// ================= USERS SERVICE ================= //

const findUserByEmail = async (email) => {
  if (isLiveMongo()) {
    return await User.findOne({ email: email.toLowerCase() });
  } else {
    return inMemoryUsers.find((u) => u.email.toLowerCase() === email.toLowerCase()) || null;
  }
};

const findUserById = async (id) => {
  if (isLiveMongo()) {
    return await User.findById(id).select('-password');
  } else {
    const user = inMemoryUsers.find((u) => u._id.toString() === id.toString() || u.id === id);
    if (!user) return null;
    const copy = { ...user };
    delete copy.password;
    return copy;
  }
};

const createUser = async ({ name, email, password, role, phone, location }) => {
  if (isLiveMongo()) {
    const user = new User({
      name,
      email: email.toLowerCase(),
      password,
      role: role || 'user',
      phone: phone || '',
      location: location || 'General',
    });
    await user.save();
    return user;
  } else {
    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(password, salt);
    const newId = new mongoose.Types.ObjectId().toString();

    const newUser = {
      _id: newId,
      id: newId,
      name,
      email: email.toLowerCase(),
      password: hashedPassword,
      role: role || 'user',
      phone: phone || '',
      location: location || 'General',
      savedContacts: [],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    inMemoryUsers.push(newUser);
    const result = { ...newUser };
    delete result.password;
    return result;
  }
};

const toggleSaveContact = async (userId, contactId) => {
  if (isLiveMongo()) {
    const user = await User.findById(userId);
    if (!user) return null;

    const index = user.savedContacts.findIndex((id) => id.toString() === contactId.toString());
    let saved = false;
    if (index > -1) {
      user.savedContacts.splice(index, 1);
      saved = false;
    } else {
      user.savedContacts.push(contactId);
      saved = true;
    }
    await user.save();
    return { saved, savedContacts: user.savedContacts };
  } else {
    const user = inMemoryUsers.find((u) => u._id.toString() === userId.toString() || u.id === userId);
    if (!user) return null;

    if (!user.savedContacts) user.savedContacts = [];
    const index = user.savedContacts.indexOf(contactId);
    let saved = false;
    if (index > -1) {
      user.savedContacts.splice(index, 1);
      saved = false;
    } else {
      user.savedContacts.push(contactId);
      saved = true;
    }
    return { saved, savedContacts: user.savedContacts };
  }
};

module.exports = {
  initSeedData,
  getContacts,
  getContactById,
  createContact,
  updateContact,
  deleteContact,
  getStats,
  resetAndSeedContacts,
  findUserByEmail,
  findUserById,
  createUser,
  toggleSaveContact,
};
