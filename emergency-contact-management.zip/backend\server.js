require('dotenv').config();
const express = require('express');
const cors = require('cors');
const { connectDB, getDbStatus } = require('./config/db');
const { initSeedData } = require('./services/dataService');

const authRoutes = require('./routes/authRoutes');
const contactRoutes = require('./routes/contactRoutes');
const emergencyRoutes = require('./routes/emergencyRoutes');

const app = express();
const PORT = process.env.PORT || 5000;

// Enable CORS for frontend development
app.use(
  cors({
    origin: '*',
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Authorization'],
  })
);

// Body Parser Middleware
app.use(express.json());

// Request logger
app.use((req, res, next) => {
  const start = Date.now();
  res.on('finish', () => {
    const duration = Date.now() - start;
    console.log(`[HTTP] ${req.method} ${req.originalUrl} -> ${res.statusCode} (${duration}ms)`);
  });
  next();
});

// Health & System Info Route
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ONLINE',
    service: 'Emergency Contact Management System API',
    version: '1.0.0',
    timestamp: new Date().toISOString(),
    database: getDbStatus(),
  });
});

// Project Information & Objectives Endpoint
app.get('/api/project-info', (req, res) => {
  res.json({
    projectName: 'Emergency Contact & Services Management System',
    description: 'A full-stack MERN application for cataloging, searching, and managing rapid response emergency contacts and critical public services.',
    stack: {
      frontend: 'React.js (Vite), Modern UI, Lucide Icons',
      backend: 'Node.js & Express.js RESTful API Architecture',
      database: 'MongoDB & Mongoose ODM (Dual-Mode Live & Resilient Store)',
      authentication: 'JWT (JSON Web Token) with bcrypt password hashing',
    },
    objectives: [
      { id: 1, title: 'Demonstrate MERN Stack development', status: 'Completed', details: 'Full integration of MongoDB, Express.js, React.js, and Node.js.' },
      { id: 2, title: 'Implement CRUD operations using MongoDB', status: 'Completed', details: 'Create, Read, Update, Delete for emergency contacts with schema validation.' },
      { id: 3, title: 'Build REST APIs using Node.js and Express.js', status: 'Completed', details: 'Clean REST endpoints for contacts, auth, search, filtering, and stats.' },
      { id: 4, title: 'Develop frontend using React.js', status: 'Completed', details: 'Interactive single-page application with rapid filtering, search, and responsive cards.' },
      { id: 5, title: 'Implement authentication and role-based access', status: 'Completed', details: 'Admin privileges (add/edit/delete/seed) vs Standard User privileges (view, bookmark, SOS).' },
      { id: 6, title: 'Display project information and results clearly', status: 'Completed', details: 'Integrated dashboard, visual statistics, and live API status monitor.' },
    ],
    features: [
      'Fast Emergency Dialing & Copy-to-Clipboard',
      'Dynamic multi-criteria search and filter (category, city, priority, status)',
      '24/7 Availability badge & Priority level indicator',
      'One-Click Demo Account Switching (Admin / User)',
      'Interactive Emergency SOS alert simulator with geocoding',
      'Role-based access controls protecting registry updates',
    ],
  });
});

// Mount Application Routes
app.use('/api/auth', authRoutes);
app.use('/api/contacts', contactRoutes);
app.use('/api/emergency', emergencyRoutes);

// Download Project Zip Route
app.get('/api/download-zip', (req, res) => {
  const fs = require('fs');
  const path = require('path');
  const candidates = [
    path.resolve(__dirname, '../emergency-contact-management.zip'),
    path.resolve(__dirname, '../../emergency-contact-management.zip'),
    'C:\\Users\\n_sat\\.gemini\\antigravity\\scratch\\emergency-contact-management.zip',
    'C:\\Users\\n_sat\\Downloads\\emergency-contact-management.zip',
  ];

  for (const p of candidates) {
    if (fs.existsSync(p)) {
      return res.download(p, 'emergency-contact-management.zip');
    }
  }

  res.status(404).json({ success: false, message: 'ZIP bundle file not found on server.' });
});

// 404 Handler
app.use('*', (req, res) => {
  res.status(404).json({
    success: false,
    message: `API endpoint '${req.originalUrl}' not found.`,
  });
});

// Global Error Handler
app.use((err, req, res, next) => {
  console.error('Unhandled server error:', err);
  res.status(500).json({
    success: false,
    message: 'Internal server error: ' + (err.message || 'Unknown error'),
  });
});

// Start Server and Initialize Database
const startServer = async () => {
  try {
    await connectDB();
    await initSeedData();

    app.listen(PORT, () => {
      console.log('====================================================');
      console.log(`🚨 Emergency Contact Management API running on: http://localhost:${PORT}`);
      console.log(`📡 Health Check: http://localhost:${PORT}/api/health`);
      console.log(`📋 Contacts API: http://localhost:${PORT}/api/contacts`);
      console.log('====================================================');
    });
  } catch (error) {
    console.error('Fatal initialization error:', error);
  }
};

startServer();
