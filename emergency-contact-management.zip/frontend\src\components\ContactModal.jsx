import React, { useState, useEffect } from 'react';
import { X, ShieldAlert, CheckCircle2, AlertCircle } from 'lucide-react';

export const ContactModal = ({
  isOpen,
  onClose,
  onSubmit,
  initialData = null,
  categories = [],
}) => {
  const [formData, setFormData] = useState({
    name: '',
    service: 'Ambulance / Medical Emergency',
    phone: '',
    alternatePhone: '',
    location: {
      address: '',
      city: '',
      state: '',
    },
    priority: 'High',
    operatingHours: '24/7 Available',
    description: '',
    status: 'Active',
  });

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    if (initialData) {
      setFormData({
        name: initialData.name || '',
        service: initialData.service || 'Ambulance / Medical Emergency',
        phone: initialData.phone || '',
        alternatePhone: initialData.alternatePhone || '',
        location: {
          address: initialData.location?.address || '',
          city: initialData.location?.city || '',
          state: initialData.location?.state || '',
        },
        priority: initialData.priority || 'High',
        operatingHours: initialData.operatingHours || '24/7 Available',
        description: initialData.description || '',
        status: initialData.status || 'Active',
      });
    } else {
      setFormData({
        name: '',
        service: categories[0] || 'Ambulance / Medical Emergency',
        phone: '',
        alternatePhone: '',
        location: { address: '', city: '', state: '' },
        priority: 'High',
        operatingHours: '24/7 Available',
        description: '',
        status: 'Active',
      });
    }
    setError('');
  }, [initialData, isOpen, categories]);

  if (!isOpen) return null;

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');

    // Validation
    if (!formData.name.trim()) {
      setError('Please provide the emergency service or contact name.');
      return;
    }
    if (!formData.phone.trim()) {
      setError('Primary emergency phone number is required.');
      return;
    }
    if (!formData.location.city.trim() || !formData.location.address.trim()) {
      setError('Both address and city are required for emergency dispatch.');
      return;
    }

    setLoading(true);
    try {
      await onSubmit(formData);
      onClose();
    } catch (err) {
      setError(err.message || 'Operation failed. Please check inputs.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-content" onClick={(e) => e.stopPropagation()}>
        
        {/* Modal Header */}
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '1.25rem', borderBottom: '1px solid var(--border-subtle)', paddingBottom: '0.85rem' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem' }}>
            <div style={{
              width: '32px',
              height: '32px',
              borderRadius: '8px',
              backgroundColor: initialData ? 'rgba(59, 130, 246, 0.15)' : 'rgba(239, 68, 68, 0.15)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
            }}>
              <ShieldAlert size={18} color={initialData ? 'var(--accent-blue)' : 'var(--accent-red)'} />
            </div>
            <div>
              <h3 style={{ fontSize: '1.2rem', fontWeight: 800, color: 'var(--text-main)', margin: 0 }}>
                {initialData ? 'Update Emergency Contact' : 'Register New Emergency Service'}
              </h3>
              <p style={{ fontSize: '0.75rem', color: 'var(--text-muted)', margin: 0 }}>
                {initialData ? 'Modify verified response details' : 'Add to live public emergency responder registry'}
              </p>
            </div>
          </div>

          <button onClick={onClose} className="btn btn-ghost btn-sm" style={{ padding: '0.25rem' }}>
            <X size={20} />
          </button>
        </div>

        {error && (
          <div style={{
            backgroundColor: 'rgba(239, 68, 68, 0.15)',
            border: '1px solid rgba(239, 68, 68, 0.3)',
            borderRadius: '0.5rem',
            padding: '0.75rem 1rem',
            marginBottom: '1rem',
            color: 'var(--accent-red)',
            fontSize: '0.82rem',
            display: 'flex',
            alignItems: 'center',
            gap: '0.5rem',
          }}>
            <AlertCircle size={16} />
            <span>{error}</span>
          </div>
        )}

        {/* Form Body */}
        <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
          
          {/* Service Name */}
          <div>
            <label style={{ display: 'block', fontSize: '0.78rem', fontWeight: 600, color: 'var(--text-main)', marginBottom: '0.35rem' }}>
              Service / Contact Name *
            </label>
            <input
              type="text"
              className="input"
              placeholder="e.g. City Central Police Station or Dr. John Doe"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              required
            />
          </div>

          {/* Service Category & Priority */}
          <div style={{ display: 'grid', gridTemplateColumns: '1.4fr 1fr', gap: '0.75rem' }}>
            <div>
              <label style={{ display: 'block', fontSize: '0.78rem', fontWeight: 600, color: 'var(--text-main)', marginBottom: '0.35rem' }}>
                Emergency Category *
              </label>
              <select
                className="select"
                value={formData.service}
                onChange={(e) => setFormData({ ...formData, service: e.target.value })}
              >
                {categories.map((c) => (
                  <option key={c} value={c}>
                    {c}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label style={{ display: 'block', fontSize: '0.78rem', fontWeight: 600, color: 'var(--text-main)', marginBottom: '0.35rem' }}>
                Priority Level
              </label>
              <select
                className="select"
                value={formData.priority}
                onChange={(e) => setFormData({ ...formData, priority: e.target.value })}
              >
                <option value="Critical">Critical (Immediate)</option>
                <option value="High">High Priority</option>
                <option value="Standard">Standard</option>
              </select>
            </div>
          </div>

          {/* Primary Phone & Alternate Phone */}
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.75rem' }}>
            <div>
              <label style={{ display: 'block', fontSize: '0.78rem', fontWeight: 600, color: 'var(--text-main)', marginBottom: '0.35rem' }}>
                Primary Phone Number *
              </label>
              <input
                type="text"
                className="input"
                placeholder="e.g. 112, 100, or +1-800-555-0199"
                value={formData.phone}
                onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                required
              />
            </div>

            <div>
              <label style={{ display: 'block', fontSize: '0.78rem', fontWeight: 600, color: 'var(--text-main)', marginBottom: '0.35rem' }}>
                Alternate / Backup Phone
              </label>
              <input
                type="text"
                className="input"
                placeholder="e.g. +1-555-019-2834"
                value={formData.alternatePhone}
                onChange={(e) => setFormData({ ...formData, alternatePhone: e.target.value })}
              />
            </div>
          </div>

          {/* Location: City and State */}
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.75rem' }}>
            <div>
              <label style={{ display: 'block', fontSize: '0.78rem', fontWeight: 600, color: 'var(--text-main)', marginBottom: '0.35rem' }}>
                City / Region *
              </label>
              <input
                type="text"
                className="input"
                placeholder="e.g. Downtown Metro"
                value={formData.location.city}
                onChange={(e) =>
                  setFormData({
                    ...formData,
                    location: { ...formData.location, city: e.target.value },
                  })
                }
                required
              />
            </div>

            <div>
              <label style={{ display: 'block', fontSize: '0.78rem', fontWeight: 600, color: 'var(--text-main)', marginBottom: '0.35rem' }}>
                State / District
              </label>
              <input
                type="text"
                className="input"
                placeholder="e.g. Capital State"
                value={formData.location.state}
                onChange={(e) =>
                  setFormData({
                    ...formData,
                    location: { ...formData.location, state: e.target.value },
                  })
                }
              />
            </div>
          </div>

          {/* Street Address */}
          <div>
            <label style={{ display: 'block', fontSize: '0.78rem', fontWeight: 600, color: 'var(--text-main)', marginBottom: '0.35rem' }}>
              Full Dispatch Street Address *
            </label>
            <input
              type="text"
              className="input"
              placeholder="e.g. 742 Evergreen Terrace, Sector 4, Civic Center"
              value={formData.location.address}
              onChange={(e) =>
                setFormData({
                  ...formData,
                  location: { ...formData.location, address: e.target.value },
                })
              }
              required
            />
          </div>

          {/* Hours & Status */}
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.75rem' }}>
            <div>
              <label style={{ display: 'block', fontSize: '0.78rem', fontWeight: 600, color: 'var(--text-main)', marginBottom: '0.35rem' }}>
                Operational Hours
              </label>
              <input
                type="text"
                className="input"
                placeholder="e.g. 24/7 Available or 08:00 - 20:00"
                value={formData.operatingHours}
                onChange={(e) => setFormData({ ...formData, operatingHours: e.target.value })}
              />
            </div>

            <div>
              <label style={{ display: 'block', fontSize: '0.78rem', fontWeight: 600, color: 'var(--text-main)', marginBottom: '0.35rem' }}>
                Operational Status
              </label>
              <select
                className="select"
                value={formData.status}
                onChange={(e) => setFormData({ ...formData, status: e.target.value })}
              >
                <option value="Active">Active & Responding</option>
                <option value="Busy">High Load / Busy</option>
                <option value="Under Maintenance">Under Maintenance</option>
              </select>
            </div>
          </div>

          {/* Description */}
          <div>
            <label style={{ display: 'block', fontSize: '0.78rem', fontWeight: 600, color: 'var(--text-main)', marginBottom: '0.35rem' }}>
              Specialization / Equipment / Protocol Notes
            </label>
            <textarea
              className="textarea"
              rows={2}
              placeholder="e.g. Equipped with cardiac defibrillator, ICU ambulances, rapid disaster triage unit..."
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
            />
          </div>

          {/* Modal Actions */}
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'flex-end', gap: '0.75rem', marginTop: '0.5rem', borderTop: '1px solid var(--border-subtle)', paddingTop: '1rem' }}>
            <button type="button" onClick={onClose} className="btn btn-secondary" disabled={loading}>
              Cancel
            </button>
            <button
              type="submit"
              className={initialData ? 'btn btn-blue' : 'btn btn-primary'}
              disabled={loading}
            >
              {loading ? 'Saving to Database...' : initialData ? 'Save Changes' : 'Register Contact'}
            </button>
          </div>

        </form>

      </div>
    </div>
  );
};
