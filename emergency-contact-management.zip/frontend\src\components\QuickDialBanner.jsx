import React, { useState } from 'react';
import { Phone, Shield, Ambulance, Flame, HeartHandshake, Copy, Check } from 'lucide-react';

export const QuickDialBanner = () => {
  const [copiedNumber, setCopiedNumber] = useState(null);

  const quickServices = [
    { name: 'National SOS', code: '112', icon: Shield, color: '#ef4444', desc: 'Unified Dispatch' },
    { name: 'Police Helpline', code: '100', icon: Shield, color: '#3b82f6', desc: 'Law Enforcement' },
    { name: 'Ambulance / ER', code: '108', icon: Ambulance, color: '#10b981', desc: 'Medical Response' },
    { name: 'Fire & Rescue', code: '101', icon: Flame, color: '#f97316', desc: 'Fire Brigade' },
    { name: 'Women Safety', code: '1091', icon: HeartHandshake, color: '#ec4899', desc: '24/7 Helpline' },
  ];

  const handleCopy = (code, e) => {
    e.stopPropagation();
    navigator.clipboard.writeText(code);
    setCopiedNumber(code);
    setTimeout(() => setCopiedNumber(null), 2000);
  };

  return (
    <div style={{ backgroundColor: 'var(--banner-bg)', borderBottom: '1px solid var(--border-subtle)', padding: '0.85rem 0' }}>
      <div className="container">
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '0.75rem' }}>
          
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
            <span style={{
              display: 'inline-block',
              width: '8px',
              height: '8px',
              borderRadius: '50%',
              backgroundColor: 'var(--accent-red)',
              boxShadow: '0 0 8px var(--accent-red)'
            }} />
            <span style={{ fontSize: '0.78rem', fontWeight: 700, color: 'var(--text-main)', letterSpacing: '0.04em', textTransform: 'uppercase' }}>
              Priority Speed Dial Strip:
            </span>
          </div>

          <div style={{ display: 'flex', alignItems: 'center', gap: '0.65rem', flexWrap: 'wrap' }}>
            {quickServices.map((s) => {
              const Icon = s.icon;
              const isCopied = copiedNumber === s.code;

              return (
                <div
                  key={s.code}
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '0.5rem',
                    backgroundColor: 'var(--bg-card)',
                    border: '1px solid var(--border-subtle)',
                    borderRadius: '8px',
                    padding: '0.35rem 0.65rem',
                    boxShadow: 'var(--shadow-sm)',
                  }}
                >
                  <div style={{
                    width: '24px',
                    height: '24px',
                    borderRadius: '6px',
                    backgroundColor: `${s.color}20`,
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}>
                    <Icon size={14} color={s.color} />
                  </div>

                  <div>
                    <span style={{ fontSize: '0.7rem', color: 'var(--text-muted)', display: 'block', lineHeight: 1 }}>
                      {s.name}
                    </span>
                    <span style={{ fontSize: '0.9rem', fontWeight: 800, color: 'var(--text-main)', letterSpacing: '0.02em' }}>
                      {s.code}
                    </span>
                  </div>

                  <div style={{ display: 'flex', alignItems: 'center', gap: '0.2rem', marginLeft: '0.25rem' }}>
                    <a
                      href={`tel:${s.code}`}
                      className="btn btn-ghost"
                      style={{ padding: '0.2rem', minWidth: 'auto', borderRadius: '4px' }}
                      title={`Call ${s.code}`}
                    >
                      <Phone size={13} color="#10b981" />
                    </a>
                    <button
                      onClick={(e) => handleCopy(s.code, e)}
                      className="btn btn-ghost"
                      style={{ padding: '0.2rem', minWidth: 'auto', borderRadius: '4px' }}
                      title="Copy Number"
                    >
                      {isCopied ? <Check size={13} color="#10b981" /> : <Copy size={13} color="var(--text-muted)" />}
                    </button>
                  </div>
                </div>
              );
            })}
          </div>

        </div>
      </div>
    </div>
  );
};
