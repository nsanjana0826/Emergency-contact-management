const express = require('express');
const router = express.Router();
const {
  getContacts,
  getContactById,
  createContact,
  updateContact,
  deleteContact,
  getStats,
  resetAndSeedContacts,
} = require('../services/dataService');
const { verifyToken, requireAdmin, optionalAuth } = require('../middleware/authMiddleware');

// Get all contacts with query filters
router.get('/', optionalAuth, async (req, res) => {
  try {
    const { q, service, city, priority, status, sort } = req.query;
    const contacts = await getContacts({ q, service, city, priority, status, sort });

    res.json({
      success: true,
      count: contacts.length,
      data: contacts,
    });
  } catch (err) {
    console.error('Error fetching contacts:', err);
    res.status(500).json({
      success: false,
      message: 'Failed to retrieve emergency contacts: ' + err.message,
    });
  }
});

// Get emergency statistics & analytics
router.get('/stats/overview', async (req, res) => {
  try {
    const stats = await getStats();
    res.json({
      success: true,
      data: stats,
    });
  } catch (err) {
    res.status(500).json({
      success: false,
      message: 'Failed to calculate system statistics: ' + err.message,
    });
  }
});

// Get metadata (categories, priority levels, cities)
router.get('/meta/categories', async (req, res) => {
  try {
    const stats = await getStats();
    const categories = [
      'Police / Law Enforcement',
      'Ambulance / Medical Emergency',
      'Fire & Rescue Service',
      'Hospital & Emergency Room',
      'Disaster & Helpline',
      'Women & Child Helpline',
      'Blood Bank / Organ Bank',
      'Poison Control & Toxic Helpline',
      'Utility / Electric & Gas Emergency',
      'Personal / Family Emergency',
    ];
    res.json({
      success: true,
      categories,
      priorities: ['Critical', 'High', 'Standard'],
      cities: stats.uniqueCities || [],
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// Get single contact by ID
router.get('/:id', async (req, res) => {
  try {
    const contact = await getContactById(req.params.id);
    if (!contact) {
      return res.status(404).json({
        success: false,
        message: 'Emergency contact record not found with ID: ' + req.params.id,
      });
    }
    res.json({
      success: true,
      data: contact,
    });
  } catch (err) {
    res.status(500).json({
      success: false,
      message: 'Error looking up emergency contact: ' + err.message,
    });
  }
});

// Create new contact (Protected: admin or authenticated user)
router.post('/', verifyToken, async (req, res) => {
  try {
    const { name, service, phone, location } = req.body;

    if (!name || !service || !phone) {
      return res.status(400).json({
        success: false,
        message: 'Name, Service Category, and Phone number are required fields.',
      });
    }

    if (!location || !location.address || !location.city) {
      return res.status(400).json({
        success: false,
        message: 'Location requires both address and city.',
      });
    }

    const contact = await createContact(req.body, req.user);

    res.status(201).json({
      success: true,
      message: 'Emergency contact registered successfully.',
      data: contact,
    });
  } catch (err) {
    console.error('Error creating contact:', err);
    res.status(400).json({
      success: false,
      message: 'Could not create contact: ' + err.message,
    });
  }
});

// Update contact (Protected: Admin role required for official registry integrity)
router.put('/:id', verifyToken, requireAdmin, async (req, res) => {
  try {
    const existing = await getContactById(req.params.id);
    if (!existing) {
      return res.status(404).json({
        success: false,
        message: 'Cannot update: Emergency contact not found.',
      });
    }

    const updated = await updateContact(req.params.id, req.body);

    res.json({
      success: true,
      message: 'Emergency contact updated successfully.',
      data: updated,
    });
  } catch (err) {
    console.error('Error updating contact:', err);
    res.status(400).json({
      success: false,
      message: 'Could not update contact: ' + err.message,
    });
  }
});

// Delete contact (Protected: Admin role required)
router.delete('/:id', verifyToken, requireAdmin, async (req, res) => {
  try {
    const existing = await getContactById(req.params.id);
    if (!existing) {
      return res.status(404).json({
        success: false,
        message: 'Cannot delete: Emergency contact not found.',
      });
    }

    const deleted = await deleteContact(req.params.id);

    res.json({
      success: true,
      message: `Emergency contact '${existing.name}' has been deleted.`,
      data: deleted,
    });
  } catch (err) {
    console.error('Error deleting contact:', err);
    res.status(500).json({
      success: false,
      message: 'Could not delete contact: ' + err.message,
    });
  }
});

// Re-seed default dataset (Protected: Admin role)
router.post('/seed/reset', verifyToken, requireAdmin, async (req, res) => {
  try {
    const contacts = await resetAndSeedContacts();
    res.json({
      success: true,
      message: 'Registry reset and successfully seeded with official emergency service contacts.',
      count: contacts.length,
      data: contacts,
    });
  } catch (err) {
    res.status(500).json({
      success: false,
      message: 'Seeding failed: ' + err.message,
    });
  }
});

module.exports = router;
