import React, { createContext, useContext, useState, useEffect } from 'react';
import { api } from '../api/client';

const AuthContext = createContext(null);

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [token, setToken] = useState(() => localStorage.getItem('emergency_token'));
  const [loading, setLoading] = useState(true);
  const [demoAccounts, setDemoAccounts] = useState(null);

  // Load user on token change
  useEffect(() => {
    const loadCurrentUser = async () => {
      if (!token) {
        setUser(null);
        setLoading(false);
        return;
      }

      try {
        const res = await api.getMe();
        if (res.success && res.user) {
          setUser(res.user);
        } else {
          logout();
        }
      } catch (err) {
        console.warn('Session expired or invalid, logging out.');
        logout();
      } finally {
        setLoading(false);
      }
    };

    loadCurrentUser();
  }, [token]);

  // Fetch demo accounts for one-click login
  useEffect(() => {
    api.getDemoAccounts()
      .then((data) => setDemoAccounts(data))
      .catch((err) => console.error('Failed to fetch demo accounts:', err));
  }, []);

  const login = async (email, password) => {
    const res = await api.login({ email, password });
    if (res.success && res.token) {
      localStorage.setItem('emergency_token', res.token);
      setToken(res.token);
      setUser(res.user);
      return res;
    }
    throw new Error(res.message || 'Login failed');
  };

  const register = async (userData) => {
    const res = await api.register(userData);
    if (res.success && res.token) {
      localStorage.setItem('emergency_token', res.token);
      setToken(res.token);
      setUser(res.user);
      return res;
    }
    throw new Error(res.message || 'Registration failed');
  };

  const logout = () => {
    localStorage.removeItem('emergency_token');
    setToken(null);
    setUser(null);
  };

  const quickLogin = async (roleName) => {
    if (!demoAccounts || !demoAccounts[roleName]) {
      // fallback defaults
      const creds =
        roleName === 'admin'
          ? { email: 'admin@emergency.org', password: 'AdminPassword123!' }
          : { email: 'user@emergency.org', password: 'UserPassword123!' };
      return await login(creds.email, creds.password);
    }
    const acc = demoAccounts[roleName];
    return await login(acc.email, acc.password);
  };

  const toggleFavorite = async (contactId) => {
    if (!user) return false;
    try {
      const res = await api.toggleSaveContact(contactId);
      if (res.success) {
        setUser((prev) => ({
          ...prev,
          savedContacts: res.savedContacts,
        }));
        return res.saved;
      }
    } catch (err) {
      console.error('Error toggling favorite:', err);
    }
    return false;
  };

  const isAdmin = user?.role === 'admin';

  return (
    <AuthContext.Provider
      value={{
        user,
        token,
        loading,
        isAdmin,
        login,
        register,
        logout,
        quickLogin,
        toggleFavorite,
        demoAccounts,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
