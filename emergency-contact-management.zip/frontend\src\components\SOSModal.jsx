import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { api } from '../api/client';
import {
  Radio,
  X,
  AlertOctagon,
  CheckCircle,
  MapPin,
  PhoneCall,
  Loader2,
  Ambulance,
  Shield,
  Flame,
  Hospital,
} from 'lucide-react';

export const SOSModal = ({ isOpen, onClose, onIncidentCreated }) => {
  const { user } = useAuth();
  const [emergencyType, setEmergencyType] = useState('Ambulance / Medical Emergency');
  const [callerName, setCallerName] = useState(user?.name || '');
  const [userPhone, setUserPhone] = useState(user?.phone || '');
  const [customMessage, setCustomMessage] = useState('');
  const [locationStatus, setLocationStatus] = useState('Default GPS: Central Command (28.6139° N, 77.2090° E)');
  const [loading, setLoading] = useState(false);
  const [sosResult, setSosResult] = useState(null);

  if (!isOpen) return null;

  const handleGetLocation = () => {
    if ('geolocation' in navigator) {
      setLocationStatus('Acquiring live satellite coordinates...');
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          setLocationStatus(
            `Live GPS: Lat ${pos.coords.latitude.toFixed(4)}, Lng ${pos.coords.longitude.toFixed(4)}`
          );
        },
        () => {
          setLocationStatus('GPS permission denied. Using Sector Geo-IP location.');
        }
      );
    } else {
      setLocationStatus('Geolocation API unavailable on this browser.');
    }
  };

  const handleBroadcast = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      const res = await api.triggerSOS({
        emergencyType,
        callerName: callerName || (user ? user.name : 'Anonymous Caller'),
        userPhone: userPhone || '+1-555-EMERGENCY',
        customMessage: customMessage || 'Immediate life-safety responder assistance required.',
      });

      if (res.success && res.alert) {
        setSosResult(res.alert);
        if (onIncidentCreated) {
          onIncidentCreated(res.alert);
        }
      }
    } catch (err) {
      alert('SOS broadcast failed: ' + err.message);
    } finally {
      setLoading(false);
    }
  };

  const resetAndClose = () => {
    setSosResult(null);
    onClose();
  };

  return (
    <div className="modal-overlay" onClick={resetAndClose}>
      <div
        className="modal-content"
        style={{
          border: '1px solid rgba(239, 68, 68, 0.4)',
          boxShadow: 'var(--shadow-glow-red)',
        }}
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', borderBottom: '1px solid var(--border-subtle)', paddingBottom: '0.85rem', marginBottom: '1.25rem' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.65rem' }}>
            <div
              style={{
                width: '36px',
                height: '36px',
                borderRadius: '8px',
                backgroundColor: 'rgba(239, 68, 68, 0.2)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
              }}
            >
              <AlertOctagon size={22} color="var(--accent-red)" />
            </div>
            <div>
              <h3 style={{ fontSize: '1.2rem', fontWeight: 800, color: 'var(--text-main)', margin: 0 }}>
                CRITICAL SOS EMERGENCY DISPATCH
              </h3>
              <p style={{ fontSize: '0.75rem', color: 'var(--accent-red)', margin: 0, fontWeight: 600 }}>
                Broadcast incident coordinates to nearest responder units
              </p>
            </div>
          </div>

          <button onClick={resetAndClose} className="btn btn-ghost btn-sm" style={{ padding: '0.25rem' }}>
            <X size={20} />
          </button>
        </div>

        {/* If broadcast completed: show confirmation screen */}
        {sosResult ? (
          <div>
            <div
              style={{
                backgroundColor: 'rgba(16, 185, 129, 0.12)',
                border: '1px solid rgba(16, 185, 129, 0.3)',
                borderRadius: '0.75rem',
                padding: '1.25rem',
                textAlign: 'center',
                marginBottom: '1.25rem',
              }}
            >
              <CheckCircle size={42} color="#10b981" style={{ margin: '0 auto 0.5rem auto' }} />
              <h4 style={{ fontSize: '1.15rem', fontWeight: 800, color: '#10b981', marginBottom: '0.25rem' }}>
                DISPATCH ORDER CONFIRMED
              </h4>
              <p style={{ fontSize: '0.82rem', color: 'var(--text-main)', margin: 0 }}>
                Incident ID: <strong>{sosResult.incidentId}</strong>
              </p>
              <p style={{ fontSize: '0.75rem', color: 'var(--text-muted)', margin: '0.25rem 0 0 0' }}>
                Dispatched at: {new Date(sosResult.timestamp).toLocaleTimeString()}
              </p>
            </div>

            <h5 style={{ fontSize: '0.82rem', color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: '0.65rem' }}>
              First Responder Units Alerted:
            </h5>

            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem', marginBottom: '1.5rem' }}>
              {sosResult.dispatchedContacts.map((c) => (
                <div
                  key={c.id || c.name}
                  style={{
                    backgroundColor: 'var(--box-inner-bg)',
                    border: '1px solid var(--border-subtle)',
                    borderRadius: '0.5rem',
                    padding: '0.75rem 1rem',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                  }}
                >
                  <div>
                    <h5 style={{ fontSize: '0.9rem', fontWeight: 700, color: 'var(--text-main)', margin: 0 }}>{c.name}</h5>
                    <span style={{ fontSize: '0.72rem', color: 'var(--text-muted)' }}>{c.service}</span>
                  </div>

                  <a
                    href={`tel:${c.phone}`}
                    className="btn btn-primary btn-sm"
                    style={{ fontSize: '0.75rem' }}
                  >
                    <PhoneCall size={13} />
                    <span>Dial {c.phone}</span>
                  </a>
                </div>
              ))}
            </div>

            <div style={{ display: 'flex', justifyContent: 'flex-end' }}>
              <button onClick={resetAndClose} className="btn btn-secondary" style={{ width: '100%' }}>
                Return to Command Center
              </button>
            </div>
          </div>
        ) : (
          /* Form for triggering SOS */
          <form onSubmit={handleBroadcast} style={{ display: 'flex', flexDirection: 'column', gap: '1.1rem' }}>
            
            {/* Emergency Type Selector */}
            <div>
              <label style={{ display: 'block', fontSize: '0.78rem', fontWeight: 700, color: 'var(--text-main)', marginBottom: '0.45rem' }}>
                SELECT EMERGENCY TYPE *
              </label>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.5rem' }}>
                {[
                  { label: 'Medical Emergency', value: 'Ambulance / Medical Emergency', icon: Ambulance, color: '#ef4444' },
                  { label: 'Police / Crime', value: 'Police / Law Enforcement', icon: Shield, color: '#3b82f6' },
                  { label: 'Fire & Rescue', value: 'Fire & Rescue Service', icon: Flame, color: '#f97316' },
                  { label: 'Hospital ER', value: 'Hospital & Emergency Room', icon: Hospital, color: '#10b981' },
                ].map((item) => {
                  const Icon = item.icon;
                  const isSelected = emergencyType === item.value;
                  return (
                    <button
                      key={item.value}
                      type="button"
                      onClick={() => setEmergencyType(item.value)}
                      style={{
                        display: 'flex',
                        alignItems: 'center',
                        gap: '0.6rem',
                        padding: '0.7rem 0.85rem',
                        borderRadius: '0.5rem',
                        border: isSelected ? `2px solid ${item.color}` : '1px solid var(--border-subtle)',
                        backgroundColor: isSelected ? `${item.color}20` : 'var(--bg-elevated)',
                        color: isSelected ? 'var(--text-main)' : 'var(--text-muted)',
                        cursor: 'pointer',
                        textAlign: 'left',
                        fontWeight: isSelected ? 700 : 500,
                        fontSize: '0.8rem',
                      }}
                    >
                      <Icon size={18} color={item.color} />
                      <span>{item.label}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Caller Name & Phone */}
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.75rem' }}>
              <div>
                <label style={{ display: 'block', fontSize: '0.78rem', fontWeight: 600, color: 'var(--text-main)', marginBottom: '0.35rem' }}>
                  Caller Name
                </label>
                <input
                  type="text"
                  className="input"
                  placeholder="e.g. John Doe"
                  value={callerName}
                  onChange={(e) => setCallerName(e.target.value)}
                />
              </div>

              <div>
                <label style={{ display: 'block', fontSize: '0.78rem', fontWeight: 600, color: 'var(--text-main)', marginBottom: '0.35rem' }}>
                  Callback Phone Number *
                </label>
                <input
                  type="text"
                  className="input"
                  placeholder="e.g. +1-555-019-9111"
                  value={userPhone}
                  onChange={(e) => setUserPhone(e.target.value)}
                  required
                />
              </div>
            </div>

            {/* Location Geotagging */}
            <div>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '0.35rem' }}>
                <label style={{ fontSize: '0.78rem', fontWeight: 600, color: 'var(--text-main)' }}>
                  Incident Geolocation
                </label>
                <button
                  type="button"
                  onClick={handleGetLocation}
                  className="btn btn-sm btn-ghost"
                  style={{ fontSize: '0.72rem', color: 'var(--accent-blue)' }}
                >
                  <MapPin size={12} />
                  Detect Live GPS
                </button>
              </div>
              <div
                style={{
                  backgroundColor: 'var(--box-inner-bg)',
                  border: '1px solid var(--border-subtle)',
                  borderRadius: '0.5rem',
                  padding: '0.55rem 0.85rem',
                  fontSize: '0.78rem',
                  color: 'var(--text-muted)',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '0.45rem',
                }}
              >
                <MapPin size={14} color="var(--accent-red)" />
                <span>{locationStatus}</span>
              </div>
            </div>

            {/* Incident Details */}
            <div>
              <label style={{ display: 'block', fontSize: '0.78rem', fontWeight: 600, color: 'var(--text-main)', marginBottom: '0.35rem' }}>
                Situation Details / Location Landmarks
              </label>
              <textarea
                className="textarea"
                rows={2}
                placeholder="Describe current emergency, injuries, road landmarks, or trapped individuals..."
                value={customMessage}
                onChange={(e) => setCustomMessage(e.target.value)}
              />
            </div>

            {/* Action Button */}
            <div style={{ borderTop: '1px solid var(--border-subtle)', paddingTop: '1rem', display: 'flex', gap: '0.75rem' }}>
              <button type="button" onClick={resetAndClose} className="btn btn-secondary" style={{ flex: 1 }}>
                Cancel
              </button>
              <button
                type="submit"
                disabled={loading}
                className="btn btn-primary pulse-emergency"
                style={{ flex: 2, padding: '0.75rem', fontWeight: 800, letterSpacing: '0.04em' }}
              >
                {loading ? (
                  <>
                    <Loader2 size={16} className="animate-spin" />
                    <span>Broadcasting Alert...</span>
                  </>
                ) : (
                  <>
                    <Radio size={18} />
                    <span>TRANSMIT SOS NOW</span>
                  </>
                )}
              </button>
            </div>

          </form>
        )}

      </div>
    </div>
  );
};
