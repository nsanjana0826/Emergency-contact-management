import React from 'react';
import {
  ShieldAlert,
  Activity,
  Clock,
  MapPin,
  Radio,
  PlusCircle,
  BarChart2,
  PhoneCall,
  Flame,
  Ambulance,
  Shield,
  Hospital,
  AlertTriangle,
  RefreshCw,
  CheckCircle2,
  TrendingUp,
  Server,
  Zap,
  ArrowRight,
} from 'lucide-react';

export const DashboardView = ({
  stats,
  contacts,
  incidents = [],
  dbStatus,
  onOpenSOSModal,
  onOpenAddModal,
  onOpenInfoModal,
  onNavigateDirectory,
  onResetSeed,
  isAdmin,
}) => {
  const total = stats?.totalContacts || contacts.length || 0;
  const byService = stats?.byService || {};
  const byPriority = stats?.byPriority || { Critical: 0, High: 0, Standard: 0 };
  const cities = stats?.uniqueCities || [];

  const getServiceColor = (category) => {
    const c = category.toLowerCase();
    if (c.includes('medical') || c.includes('ambulance')) return '#ef4444';
    if (c.includes('police')) return '#3b82f6';
    if (c.includes('fire')) return '#f97316';
    if (c.includes('hospital')) return '#10b981';
    if (c.includes('women') || c.includes('child')) return '#ec4899';
    if (c.includes('utility')) return '#eab308';
    return '#8b5cf6';
  };

  const getStatusBadge = (status) => {
    switch (status) {
      case 'EN_ROUTE':
        return <span className="badge badge-high">En Route 🚑</span>;
      case 'CONTAINED':
        return <span className="badge badge-green">Contained 🛡️</span>;
      case 'RESOLVED':
        return <span className="badge badge-standard">Resolved ✅</span>;
      default:
        return <span className="badge badge-critical pulse-emergency">Broadcasting 🚨</span>;
    }
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '2rem' }}>
      
      {/* Top Hero / Operational Overview Banner */}
      <div
        className="glass"
        style={{
          borderRadius: '1.25rem',
          padding: '1.75rem',
          position: 'relative',
          overflow: 'hidden',
          border: '1px solid var(--border-subtle)',
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '1.25rem' }}>
          
          <div style={{ maxWidth: '680px' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem', marginBottom: '0.6rem' }}>
              <span style={{
                display: 'inline-flex',
                alignItems: 'center',
                gap: '0.35rem',
                backgroundColor: 'rgba(16, 185, 129, 0.15)',
                color: '#10b981',
                padding: '0.2rem 0.65rem',
                borderRadius: '9999px',
                fontSize: '0.72rem',
                fontWeight: 700,
                border: '1px solid rgba(16, 185, 129, 0.3)',
              }}>
                <span style={{ width: '6px', height: '6px', borderRadius: '50%', backgroundColor: '#10b981' }} />
                ALL SYSTEMS OPERATIONAL
              </span>

              <span style={{
                fontSize: '0.72rem',
                color: 'var(--text-muted)',
                backgroundColor: 'var(--bg-card)',
                padding: '0.2rem 0.6rem',
                borderRadius: '6px',
                border: '1px solid var(--border-subtle)',
              }}>
                Database: {dbStatus?.isConnected ? 'MongoDB Active' : 'Resilient Mongoose Engine'}
              </span>
            </div>

            <h1 style={{ fontSize: '1.85rem', fontWeight: 800, color: 'var(--text-main)', letterSpacing: '-0.02em', margin: 0 }}>
              Emergency Operations Center
            </h1>
            <p style={{ fontSize: '0.9rem', color: 'var(--text-muted)', margin: '0.45rem 0 0 0', lineHeight: 1.5 }}>
              Central monitoring dashboard for rapid emergency dispatches, verified municipal responder readiness, and active distress incidents.
            </p>
          </div>

          {/* Rapid Action Buttons */}
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', flexWrap: 'wrap' }}>
            <button
              onClick={onOpenSOSModal}
              className="btn btn-primary pulse-emergency"
              style={{ fontWeight: 800, padding: '0.65rem 1.25rem', fontSize: '0.9rem' }}
            >
              <Radio size={18} />
              <span>TRIGGER RAPID SOS</span>
            </button>

            {isAdmin && (
              <button
                onClick={onOpenAddModal}
                className="btn btn-blue"
                style={{ padding: '0.65rem 1.15rem' }}
              >
                <PlusCircle size={16} />
                <span>Add Responder</span>
              </button>
            )}

            <button
              onClick={onNavigateDirectory}
              className="btn btn-secondary"
              style={{ padding: '0.65rem 1.15rem' }}
            >
              <span>View Directory</span>
              <ArrowRight size={15} />
            </button>
          </div>

        </div>
      </div>

      {/* 4 Main KPI Cards */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))', gap: '1.25rem' }}>
        
        {/* KPI 1 */}
        <div
          className="glass"
          style={{
            borderRadius: '1rem',
            padding: '1.4rem',
            border: '1px solid var(--border-subtle)',
            backgroundColor: 'var(--bg-card)',
          }}
        >
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '0.75rem' }}>
            <span style={{ fontSize: '0.78rem', color: 'var(--text-muted)', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.04em' }}>
              Total Responders
            </span>
            <div style={{ width: '36px', height: '36px', borderRadius: '8px', backgroundColor: 'rgba(59, 130, 246, 0.15)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <Shield size={18} color="#3b82f6" />
            </div>
          </div>
          <div style={{ fontSize: '2.2rem', fontWeight: 800, color: 'var(--text-main)', lineHeight: 1.1 }}>
            {total}
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem', marginTop: '0.65rem', fontSize: '0.75rem', color: '#10b981' }}>
            <TrendingUp size={14} />
            <span>100% verified registry contacts</span>
          </div>
        </div>

        {/* KPI 2 */}
        <div
          className="glass"
          style={{
            borderRadius: '1rem',
            padding: '1.4rem',
            border: '1px solid var(--border-subtle)',
            backgroundColor: 'var(--bg-card)',
          }}
        >
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '0.75rem' }}>
            <span style={{ fontSize: '0.78rem', color: 'var(--text-muted)', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.04em' }}>
              24/7 Availability
            </span>
            <div style={{ width: '36px', height: '36px', borderRadius: '8px', backgroundColor: 'rgba(16, 185, 129, 0.15)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <Clock size={18} color="#10b981" />
            </div>
          </div>
          <div style={{ fontSize: '2.2rem', fontWeight: 800, color: '#10b981', lineHeight: 1.1 }}>
            {stats?.available247 || 0}
          </div>
          <div style={{ marginTop: '0.65rem', fontSize: '0.75rem', color: 'var(--text-muted)' }}>
            Continuous night & day emergency coverage
          </div>
        </div>

        {/* KPI 3 */}
        <div
          className="glass"
          style={{
            borderRadius: '1rem',
            padding: '1.4rem',
            border: '1px solid rgba(239, 68, 68, 0.25)',
            backgroundColor: 'var(--bg-card)',
          }}
        >
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '0.75rem' }}>
            <span style={{ fontSize: '0.78rem', color: 'var(--text-muted)', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.04em' }}>
              Critical Units
            </span>
            <div style={{ width: '36px', height: '36px', borderRadius: '8px', backgroundColor: 'rgba(239, 68, 68, 0.15)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <Activity size={18} color="#ef4444" />
            </div>
          </div>
          <div style={{ fontSize: '2.2rem', fontWeight: 800, color: '#ef4444', lineHeight: 1.1 }}>
            {byPriority.Critical || 0}
          </div>
          <div style={{ marginTop: '0.65rem', fontSize: '0.75rem', color: '#ef4444' }}>
            Immediate code-red dispatch triage
          </div>
        </div>

        {/* KPI 4 */}
        <div
          className="glass"
          style={{
            borderRadius: '1rem',
            padding: '1.4rem',
            border: '1px solid var(--border-subtle)',
            backgroundColor: 'var(--bg-card)',
          }}
        >
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '0.75rem' }}>
            <span style={{ fontSize: '0.78rem', color: 'var(--text-muted)', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.04em' }}>
              Cities Covered
            </span>
            <div style={{ width: '36px', height: '36px', borderRadius: '8px', backgroundColor: 'rgba(245, 158, 11, 0.15)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <MapPin size={18} color="#f59e0b" />
            </div>
          </div>
          <div style={{ fontSize: '2.2rem', fontWeight: 800, color: '#f59e0b', lineHeight: 1.1 }}>
            {stats?.totalCities || cities.length || 0}
          </div>
          <div style={{ marginTop: '0.65rem', fontSize: '0.75rem', color: 'var(--text-muted)' }}>
            Active regional municipal jurisdictions
          </div>
        </div>

      </div>

      {/* Middle Section: Service Analytics & Priority Tier */}
      <div style={{ display: 'grid', gridTemplateColumns: '1.6fr 1fr', gap: '1.5rem' }}>
        
        {/* Service Category Breakdown Chart */}
        <div
          className="glass"
          style={{
            borderRadius: '1rem',
            padding: '1.5rem',
            border: '1px solid var(--border-subtle)',
            backgroundColor: 'var(--bg-card)',
          }}
        >
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '1.25rem' }}>
            <div>
              <h3 style={{ fontSize: '1.05rem', fontWeight: 800, color: 'var(--text-main)', margin: 0 }}>
                Service Category Distribution
              </h3>
              <p style={{ fontSize: '0.75rem', color: 'var(--text-muted)', margin: '0.2rem 0 0 0' }}>
                Operational allocation across police, medical, fire, and public protection
              </p>
            </div>
            <BarChart2 size={18} color="var(--text-muted)" />
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: '0.85rem' }}>
            {Object.entries(byService).map(([category, count]) => {
              const pct = total > 0 ? Math.round((count / total) * 100) : 0;
              const color = getServiceColor(category);

              return (
                <div key={category}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.8rem', marginBottom: '0.3rem' }}>
                    <span style={{ fontWeight: 600, color: 'var(--text-main)' }}>{category}</span>
                    <span style={{ color: 'var(--text-muted)' }}>
                      <strong>{count}</strong> units ({pct}%)
                    </span>
                  </div>

                  <div style={{ width: '100%', height: '8px', backgroundColor: 'var(--bg-elevated)', borderRadius: '999px', overflow: 'hidden' }}>
                    <div
                      style={{
                        height: '100%',
                        width: `${pct}%`,
                        backgroundColor: color,
                        borderRadius: '999px',
                        transition: 'width 0.4s ease',
                      }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Priority Tiers & System Readiness */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>
          
          {/* Priority Levels */}
          <div
            className="glass"
            style={{
              borderRadius: '1rem',
              padding: '1.5rem',
              border: '1px solid var(--border-subtle)',
              backgroundColor: 'var(--bg-card)',
            }}
          >
            <h3 style={{ fontSize: '1.05rem', fontWeight: 800, color: 'var(--text-main)', marginBottom: '1rem' }}>
              Response Priority Tiers
            </h3>

            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '0.75rem', backgroundColor: 'rgba(239, 68, 68, 0.1)', borderRadius: '0.5rem', border: '1px solid rgba(239, 68, 68, 0.2)' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                  <span style={{ width: '8px', height: '8px', borderRadius: '50%', backgroundColor: '#ef4444' }} />
                  <span style={{ fontSize: '0.82rem', fontWeight: 700, color: '#ef4444' }}>Critical Priority</span>
                </div>
                <span style={{ fontSize: '1rem', fontWeight: 800, color: 'var(--text-main)' }}>{byPriority.Critical || 0}</span>
              </div>

              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '0.75rem', backgroundColor: 'rgba(245, 158, 11, 0.1)', borderRadius: '0.5rem', border: '1px solid rgba(245, 158, 11, 0.2)' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                  <span style={{ width: '8px', height: '8px', borderRadius: '50%', backgroundColor: '#f59e0b' }} />
                  <span style={{ fontSize: '0.82rem', fontWeight: 700, color: '#f59e0b' }}>High Priority</span>
                </div>
                <span style={{ fontSize: '1rem', fontWeight: 800, color: 'var(--text-main)' }}>{byPriority.High || 0}</span>
              </div>

              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '0.75rem', backgroundColor: 'rgba(59, 130, 246, 0.1)', borderRadius: '0.5rem', border: '1px solid rgba(59, 130, 246, 0.2)' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                  <span style={{ width: '8px', height: '8px', borderRadius: '50%', backgroundColor: '#3b82f6' }} />
                  <span style={{ fontSize: '0.82rem', fontWeight: 700, color: '#3b82f6' }}>Standard Response</span>
                </div>
                <span style={{ fontSize: '1rem', fontWeight: 800, color: 'var(--text-main)' }}>{byPriority.Standard || 0}</span>
              </div>
            </div>
          </div>

          {/* Quick Hub Cities */}
          <div
            className="glass"
            style={{
              borderRadius: '1rem',
              padding: '1.25rem',
              border: '1px solid var(--border-subtle)',
              backgroundColor: 'var(--bg-card)',
            }}
          >
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '0.75rem' }}>
              <span style={{ fontSize: '0.78rem', fontWeight: 700, color: 'var(--text-muted)', textTransform: 'uppercase' }}>
                Key Regional Hubs
              </span>
              <MapPin size={15} color="var(--text-muted)" />
            </div>

            <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.4rem' }}>
              {cities.map((city) => (
                <span
                  key={city}
                  style={{
                    fontSize: '0.75rem',
                    fontWeight: 600,
                    padding: '0.25rem 0.6rem',
                    borderRadius: '6px',
                    backgroundColor: 'var(--bg-elevated)',
                    color: 'var(--text-main)',
                    border: '1px solid var(--border-subtle)',
                  }}
                >
                  📍 {city}
                </span>
              ))}
            </div>
          </div>

        </div>

      </div>

      {/* Bottom Section: Recent Incidents & Rapid Responder Hotlist */}
      <div style={{ display: 'grid', gridTemplateColumns: '1.5fr 1fr', gap: '1.5rem' }}>
        
        {/* Recent Incidents Log */}
        <div
          className="glass"
          style={{
            borderRadius: '1rem',
            padding: '1.5rem',
            border: '1px solid var(--border-subtle)',
            backgroundColor: 'var(--bg-card)',
          }}
        >
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '1.25rem' }}>
            <div>
              <h3 style={{ fontSize: '1.05rem', fontWeight: 800, color: 'var(--text-main)', margin: 0 }}>
                Recent Emergency Incident Feed
              </h3>
              <p style={{ fontSize: '0.75rem', color: 'var(--text-muted)', margin: '0.2rem 0 0 0' }}>
                Live dispatch actions and caller distress reports
              </p>
            </div>
            <button
              onClick={onOpenSOSModal}
              className="btn btn-primary btn-sm"
            >
              <Radio size={13} />
              <span>Simulate SOS</span>
            </button>
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
            {incidents.length === 0 ? (
              <p style={{ fontSize: '0.85rem', color: 'var(--text-muted)', textAlign: 'center', padding: '1.5rem 0' }}>
                No active incidents recorded. Trigger an SOS to generate an incident log.
              </p>
            ) : (
              incidents.slice(0, 5).map((inc) => (
                <div
                  key={inc.incidentId}
                  style={{
                    backgroundColor: 'var(--box-inner-bg)',
                    border: '1px solid var(--border-subtle)',
                    borderRadius: '0.75rem',
                    padding: '0.85rem 1rem',
                    display: 'flex',
                    alignItems: 'flex-start',
                    justifyContent: 'space-between',
                    gap: '1rem',
                  }}
                >
                  <div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '0.25rem' }}>
                      <span style={{ fontSize: '0.82rem', fontWeight: 800, color: 'var(--text-main)', fontFamily: 'monospace' }}>
                        {inc.incidentId}
                      </span>
                      {getStatusBadge(inc.status)}
                      <span style={{ fontSize: '0.7rem', color: 'var(--text-muted)' }}>
                        {new Date(inc.timestamp).toLocaleTimeString()}
                      </span>
                    </div>

                    <p style={{ fontSize: '0.8rem', color: 'var(--text-main)', margin: '0 0 0.35rem 0', fontWeight: 500 }}>
                      {inc.message}
                    </p>

                    <div style={{ fontSize: '0.72rem', color: 'var(--text-muted)' }}>
                      Caller: <strong style={{ color: 'var(--text-main)' }}>{inc.caller}</strong> ({inc.phone}) • Type: <em>{inc.emergencyType}</em>
                    </div>
                  </div>

                  <div style={{ textAlign: 'right', flexShrink: 0 }}>
                    {inc.dispatchedContacts && inc.dispatchedContacts.length > 0 && (
                      <span style={{ fontSize: '0.7rem', color: '#10b981', display: 'block', fontWeight: 600 }}>
                        {inc.dispatchedContacts.length} Unit(s) Dispatched
                      </span>
                    )}
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Rapid Responder Hotlist */}
        <div
          className="glass"
          style={{
            borderRadius: '1rem',
            padding: '1.5rem',
            border: '1px solid var(--border-subtle)',
            backgroundColor: 'var(--bg-card)',
          }}
        >
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '1.25rem' }}>
            <h3 style={{ fontSize: '1.05rem', fontWeight: 800, color: 'var(--text-main)', margin: 0 }}>
              Rapid Responder Hotlist
            </h3>
            <button
              onClick={onNavigateDirectory}
              className="btn btn-ghost btn-sm"
              style={{ fontSize: '0.75rem', color: '#38bdf8' }}
            >
              See all →
            </button>
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: '0.65rem' }}>
            {contacts.slice(0, 4).map((c) => (
              <div
                key={c._id || c.id}
                style={{
                  backgroundColor: 'var(--box-inner-bg)',
                  border: '1px solid var(--border-subtle)',
                  borderRadius: '0.5rem',
                  padding: '0.7rem 0.85rem',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'space-between',
                }}
              >
                <div>
                  <h4 style={{ fontSize: '0.82rem', fontWeight: 700, color: 'var(--text-main)', margin: 0 }}>
                    {c.name}
                  </h4>
                  <span style={{ fontSize: '0.7rem', color: 'var(--text-muted)' }}>
                    📍 {c.location?.city} • {c.service}
                  </span>
                </div>

                <a
                  href={`tel:${c.phone}`}
                  className="btn btn-primary btn-sm"
                  style={{ padding: '0.3rem 0.6rem', fontSize: '0.72rem' }}
                >
                  <PhoneCall size={12} />
                  <span>{c.phone}</span>
                </a>
              </div>
            ))}
          </div>

          {isAdmin && (
            <div style={{ marginTop: '1.25rem', paddingTop: '1rem', borderTop: '1px solid var(--border-subtle)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <span style={{ fontSize: '0.72rem', color: 'var(--text-muted)' }}>Admin Database Maintenance:</span>
              <button
                onClick={onResetSeed}
                className="btn btn-secondary btn-sm"
                style={{ fontSize: '0.72rem' }}
              >
                <RefreshCw size={12} />
                <span>Reset Seed</span>
              </button>
            </div>
          )}

        </div>

      </div>

    </div>
  );
};
