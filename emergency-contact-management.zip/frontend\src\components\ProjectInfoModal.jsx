import React from 'react';
import {
  Info,
  X,
  CheckCircle2,
  Database,
  Layers,
  Globe,
  Lock,
} from 'lucide-react';

export const ProjectInfoModal = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  const objectives = [
    {
      title: 'Demonstrate MERN Stack development',
      desc: 'Seamless integration between MongoDB, Express.js backend, React 19 frontend, and Node.js runtime.',
      status: 'Implemented & Verified',
    },
    {
      title: 'Implement CRUD operations using MongoDB',
      desc: 'Full Create, Read, Update, and Delete operations on emergency contacts with Mongoose ODM and schema validation.',
      status: 'Implemented & Verified',
    },
    {
      title: 'Build REST APIs using Node.js and Express.js',
      desc: 'RESTful endpoints supporting search, filtering by service & city, authentication, analytics, and SOS broadcast.',
      status: 'Implemented & Verified',
    },
    {
      title: 'Develop the frontend using React.js',
      desc: 'Modern, fast UI built with React 19, responsive card/table views, instant client-side filtering, and Lucide icons.',
      status: 'Implemented & Verified',
    },
    {
      title: 'Implement authentication and role-based access',
      desc: 'JWT authentication with bcryptjs; System Admin has full write/edit/delete/seed privileges; Citizen Users have view, bookmark, and SOS dispatch capabilities.',
      status: 'Implemented & Verified',
    },
    {
      title: 'Display project information and results clearly',
      desc: 'Interactive analytics dashboard, clear operational metrics, live system health, and accessible project documentation.',
      status: 'Implemented & Verified',
    },
  ];

  const apiEndpoints = [
    { method: 'POST', path: '/api/auth/register', auth: 'Public', desc: 'Register citizen or administrator account' },
    { method: 'POST', path: '/api/auth/login', auth: 'Public', desc: 'Authenticate and receive JWT token' },
    { method: 'GET', path: '/api/auth/me', auth: 'Bearer JWT', desc: 'Retrieve current profile and speed dial contacts' },
    { method: 'GET', path: '/api/contacts', auth: 'Public', desc: 'List contacts with query search, service, city, priority filters' },
    { method: 'GET', path: '/api/contacts/:id', auth: 'Public', desc: 'Get specific emergency contact details' },
    { method: 'POST', path: '/api/contacts', auth: 'Admin / Auth', desc: 'Create new emergency service or contact record' },
    { method: 'PUT', path: '/api/contacts/:id', auth: 'Admin Only', desc: 'Update contact details and emergency response parameters' },
    { method: 'DELETE', path: '/api/contacts/:id', auth: 'Admin Only', desc: 'Remove an emergency service from official registry' },
    { method: 'GET', path: '/api/contacts/stats/overview', auth: 'Public', desc: 'Aggregated analytics by service type, city, and priority' },
    { method: 'GET', path: '/api/emergency/incidents', auth: 'Public', desc: 'Retrieve recent live emergency incident logs' },
    { method: 'POST', path: '/api/emergency/sos', auth: 'Public / Auth', desc: 'Simulate critical emergency SOS broadcast dispatch' },
  ];

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-content" style={{ maxWidth: '820px' }} onClick={(e) => e.stopPropagation()}>
        
        {/* Header */}
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', borderBottom: '1px solid var(--border-subtle)', paddingBottom: '0.85rem', marginBottom: '1.25rem' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.65rem' }}>
            <div
              style={{
                width: '36px',
                height: '36px',
                borderRadius: '8px',
                backgroundColor: 'rgba(56, 189, 248, 0.2)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
              }}
            >
              <Info size={20} color="var(--accent-blue)" />
            </div>
            <div>
              <h3 style={{ fontSize: '1.25rem', fontWeight: 800, color: 'var(--text-main)', margin: 0 }}>
                Project Overview & MERN Specification
              </h3>
              <p style={{ fontSize: '0.75rem', color: 'var(--text-muted)', margin: 0 }}>
                19. Emergency Contact Management System
              </p>
            </div>
          </div>

          <button onClick={onClose} className="btn btn-ghost btn-sm" style={{ padding: '0.25rem' }}>
            <X size={20} />
          </button>
        </div>

        {/* Problem Statement & Description */}
        <div style={{ backgroundColor: 'var(--box-inner-bg)', border: '1px solid var(--border-subtle)', borderRadius: '0.75rem', padding: '1.15rem', marginBottom: '1.25rem' }}>
          <h4 style={{ fontSize: '0.85rem', fontWeight: 700, color: 'var(--text-main)', textTransform: 'uppercase', letterSpacing: '0.04em', marginBottom: '0.45rem' }}>
            1. Problem Statement & Scope
          </h4>
          <p style={{ fontSize: '0.82rem', color: 'var(--text-main)', lineHeight: 1.5, marginBottom: '0.75rem' }}>
            Build a MERN-based emergency contact management system that manages emergency contacts and critical public services. The system manages <strong>name</strong>, <strong>service</strong>, <strong>phone</strong>, and <strong>location</strong> using MongoDB, while React provides the frontend interface and Node.js/Express.js powers the REST APIs.
          </p>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(160px, 1fr))', gap: '0.6rem' }}>
            <div style={{ backgroundColor: 'var(--bg-elevated)', borderRadius: '0.5rem', padding: '0.6rem', textAlign: 'center', border: '1px solid var(--border-subtle)' }}>
              <Database size={16} color="var(--accent-blue)" style={{ margin: '0 auto 0.2rem auto' }} />
              <div style={{ fontSize: '0.78rem', fontWeight: 700, color: 'var(--text-main)' }}>MongoDB & Mongoose</div>
              <div style={{ fontSize: '0.68rem', color: 'var(--text-muted)' }}>Schema Validation & Dual-Engine</div>
            </div>

            <div style={{ backgroundColor: 'var(--bg-elevated)', borderRadius: '0.5rem', padding: '0.6rem', textAlign: 'center', border: '1px solid var(--border-subtle)' }}>
              <Layers size={16} color="var(--accent-green)" style={{ margin: '0 auto 0.2rem auto' }} />
              <div style={{ fontSize: '0.78rem', fontWeight: 700, color: 'var(--text-main)' }}>Express.js & Node.js</div>
              <div style={{ fontSize: '0.68rem', color: 'var(--text-muted)' }}>REST APIs & Middleware</div>
            </div>

            <div style={{ backgroundColor: 'var(--bg-elevated)', borderRadius: '0.5rem', padding: '0.6rem', textAlign: 'center', border: '1px solid var(--border-subtle)' }}>
              <Globe size={16} color="var(--accent-blue)" style={{ margin: '0 auto 0.2rem auto' }} />
              <div style={{ fontSize: '0.78rem', fontWeight: 700, color: 'var(--text-main)' }}>React.js (Vite)</div>
              <div style={{ fontSize: '0.68rem', color: 'var(--text-muted)' }}>Interactive Dashboard & SPA</div>
            </div>

            <div style={{ backgroundColor: 'var(--bg-elevated)', borderRadius: '0.5rem', padding: '0.6rem', textAlign: 'center', border: '1px solid var(--border-subtle)' }}>
              <Lock size={16} color="var(--accent-amber)" style={{ margin: '0 auto 0.2rem auto' }} />
              <div style={{ fontSize: '0.78rem', fontWeight: 700, color: 'var(--text-main)' }}>JWT & RBAC</div>
              <div style={{ fontSize: '0.68rem', color: 'var(--text-muted)' }}>Admin vs Citizen Roles</div>
            </div>
          </div>
        </div>

        {/* Objectives Checklist */}
        <div style={{ marginBottom: '1.25rem' }}>
          <h4 style={{ fontSize: '0.85rem', fontWeight: 700, color: 'var(--text-main)', textTransform: 'uppercase', letterSpacing: '0.04em', marginBottom: '0.75rem' }}>
            2. Objectives Implementation Matrix
          </h4>

          <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
            {objectives.map((obj, i) => (
              <div
                key={i}
                style={{
                  backgroundColor: 'var(--box-inner-bg)',
                  border: '1px solid var(--border-subtle)',
                  borderRadius: '0.5rem',
                  padding: '0.75rem 1rem',
                  display: 'flex',
                  alignItems: 'flex-start',
                  gap: '0.75rem',
                }}
              >
                <CheckCircle2 size={18} color="var(--accent-green)" style={{ marginTop: '2px', flexShrink: 0 }} />
                <div style={{ flex: 1 }}>
                  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: '0.5rem' }}>
                    <h5 style={{ fontSize: '0.82rem', fontWeight: 700, color: 'var(--text-main)', margin: 0 }}>
                      {obj.title}
                    </h5>
                    <span className="badge badge-green" style={{ fontSize: '0.62rem' }}>
                      {obj.status}
                    </span>
                  </div>
                  <p style={{ fontSize: '0.75rem', color: 'var(--text-muted)', margin: '0.2rem 0 0 0' }}>
                    {obj.desc}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* REST API Documentation Table */}
        <div>
          <h4 style={{ fontSize: '0.85rem', fontWeight: 700, color: 'var(--text-main)', textTransform: 'uppercase', letterSpacing: '0.04em', marginBottom: '0.75rem' }}>
            3. Backend REST API Endpoints Specification
          </h4>

          <div style={{ overflowX: 'auto', backgroundColor: 'var(--bg-card)', borderRadius: '0.5rem', border: '1px solid var(--border-subtle)' }}>
            <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '0.76rem', textAlign: 'left' }}>
              <thead>
                <tr style={{ borderBottom: '1px solid var(--border-subtle)', backgroundColor: 'var(--table-header)', color: 'var(--text-muted)' }}>
                  <th style={{ padding: '0.55rem 0.75rem' }}>Method</th>
                  <th style={{ padding: '0.55rem 0.75rem' }}>Endpoint</th>
                  <th style={{ padding: '0.55rem 0.75rem' }}>Access Level</th>
                  <th style={{ padding: '0.55rem 0.75rem' }}>Description</th>
                </tr>
              </thead>
              <tbody>
                {apiEndpoints.map((ep, idx) => (
                  <tr key={idx} style={{ borderBottom: '1px solid var(--border-subtle)' }}>
                    <td style={{ padding: '0.5rem 0.75rem' }}>
                      <span
                        style={{
                          fontWeight: 700,
                          fontSize: '0.68rem',
                          padding: '0.15rem 0.4rem',
                          borderRadius: '4px',
                          color:
                            ep.method === 'GET'
                              ? 'var(--accent-blue)'
                              : ep.method === 'POST'
                              ? 'var(--accent-green)'
                              : ep.method === 'PUT'
                              ? 'var(--accent-amber)'
                              : 'var(--accent-red)',
                          backgroundColor:
                            ep.method === 'GET'
                              ? 'rgba(56, 189, 248, 0.15)'
                              : ep.method === 'POST'
                              ? 'rgba(16, 185, 129, 0.15)'
                              : ep.method === 'PUT'
                              ? 'rgba(245, 158, 11, 0.15)'
                              : 'rgba(239, 68, 68, 0.15)',
                        }}
                      >
                        {ep.method}
                      </span>
                    </td>
                    <td style={{ padding: '0.5rem 0.75rem', fontFamily: 'monospace', color: 'var(--text-main)' }}>
                      {ep.path}
                    </td>
                    <td style={{ padding: '0.5rem 0.75rem', color: 'var(--text-muted)' }}>{ep.auth}</td>
                    <td style={{ padding: '0.5rem 0.75rem', color: 'var(--text-main)' }}>{ep.desc}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Footer */}
        <div style={{ marginTop: '1.25rem', display: 'flex', justifyContent: 'flex-end', borderTop: '1px solid var(--border-subtle)', paddingTop: '1rem' }}>
          <button onClick={onClose} className="btn btn-secondary">
            Close Information
          </button>
        </div>

      </div>
    </div>
  );
};
