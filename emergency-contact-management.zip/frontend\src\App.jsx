import React, { useState, useEffect, useMemo } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { api } from './api/client';
import { Navbar } from './components/Navbar';
import { QuickDialBanner } from './components/QuickDialBanner';
import { DashboardView } from './components/DashboardView';
import { FilterBar } from './components/FilterBar';
import { ContactCard } from './components/ContactCard';
import { ContactTable } from './components/ContactTable';
import { ContactModal } from './components/ContactModal';
import { SOSModal } from './components/SOSModal';
import { StatsDashboard } from './components/StatsDashboard';
import { ProjectInfoModal } from './components/ProjectInfoModal';
import { AuthModal } from './components/AuthModal';
import { LoginPage } from './components/LoginPage';
import {
  ShieldAlert,
  Loader2,
  AlertTriangle,
  PlusCircle,
  CheckCircle2,
  FileText,
} from 'lucide-react';

const MainApp = () => {
  const { user, isAdmin } = useAuth();

  // Theme state ('dark' | 'light')
  const [theme, setTheme] = useState(() => {
    return localStorage.getItem('emergency_theme') || 'dark';
  });

  useEffect(() => {
    document.documentElement.setAttribute('data-theme', theme);
    localStorage.setItem('emergency_theme', theme);
  }, [theme]);

  const toggleTheme = () => {
    setTheme((prev) => (prev === 'dark' ? 'light' : 'dark'));
  };

  // Data states
  const [contacts, setContacts] = useState([]);
  const [categories, setCategories] = useState([]);
  const [cities, setCities] = useState([]);
  const [stats, setStats] = useState(null);
  const [incidents, setIncidents] = useState([]);
  const [dbStatus, setDbStatus] = useState(null);
  const [loading, setLoading] = useState(true);

  // Navigation tab ('dashboard' | 'directory')
  const [activeTab, setActiveTab] = useState('dashboard');

  // Filter & Search states
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [selectedCity, setSelectedCity] = useState('All');
  const [selectedPriority, setSelectedPriority] = useState('All');
  const [showOnlySaved, setShowOnlySaved] = useState(false);
  const [viewMode, setViewMode] = useState('grid');

  // Modal states
  const [isContactModalOpen, setIsContactModalOpen] = useState(false);
  const [editingContact, setEditingContact] = useState(null);
  const [isSOSOpen, setIsSOSOpen] = useState(false);
  const [isStatsOpen, setIsStatsOpen] = useState(false);
  const [isInfoOpen, setIsInfoOpen] = useState(false);
  const [isAuthOpen, setIsAuthOpen] = useState(false);

  // Toast feedback
  const [toastMessage, setToastMessage] = useState(null);

  const showToast = (msg, type = 'success') => {
    setToastMessage({ msg, type });
    setTimeout(() => setToastMessage(null), 3500);
  };

  // Fetch initial data
  const fetchData = async () => {
    try {
      setLoading(true);
      const [contactsRes, catRes, statsRes, healthRes, incidentsRes] = await Promise.all([
        api.getContacts(),
        api.getCategories(),
        api.getStats(),
        api.getHealth(),
        api.getIncidents(),
      ]);

      if (contactsRes.success) setContacts(contactsRes.data || []);
      if (catRes.success) {
        setCategories(catRes.categories || []);
        setCities(catRes.cities || []);
      }
      if (statsRes.success) setStats(statsRes.data || null);
      if (healthRes && healthRes.database) setDbStatus(healthRes.database);
      if (incidentsRes && incidentsRes.success) setIncidents(incidentsRes.data || []);
    } catch (err) {
      console.error('Failed to load initial data:', err);
      showToast('Could not reach backend API. Is the server running?', 'error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  // Filtered contacts list
  const filteredContacts = useMemo(() => {
    return contacts.filter((c) => {
      // Saved / favorites filter
      if (showOnlySaved) {
        const id = c._id || c.id;
        if (!user?.savedContacts?.includes(id)) {
          return false;
        }
      }

      // Category filter
      if (selectedCategory !== 'All' && c.service.toLowerCase() !== selectedCategory.toLowerCase()) {
        return false;
      }

      // City filter
      if (selectedCity !== 'All' && c.location?.city?.toLowerCase() !== selectedCity.toLowerCase()) {
        return false;
      }

      // Priority filter
      if (selectedPriority !== 'All' && c.priority?.toLowerCase() !== selectedPriority.toLowerCase()) {
        return false;
      }

      // Search Query
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase().trim();
        const matchesName = c.name?.toLowerCase().includes(q);
        const matchesService = c.service?.toLowerCase().includes(q);
        const matchesPhone = c.phone?.toLowerCase().includes(q);
        const matchesCity = c.location?.city?.toLowerCase().includes(q);
        const matchesAddress = c.location?.address?.toLowerCase().includes(q);
        const matchesDesc = c.description?.toLowerCase().includes(q);

        if (!matchesName && !matchesService && !matchesPhone && !matchesCity && !matchesAddress && !matchesDesc) {
          return false;
        }
      }

      return true;
    });
  }, [contacts, searchQuery, selectedCategory, selectedCity, selectedPriority, showOnlySaved, user]);

  // Handlers for CRUD
  const handleOpenAdd = () => {
    if (!user) {
      setActiveTab('login');
      showToast('Please sign in to register emergency responder units.', 'error');
      return;
    }
    setEditingContact(null);
    setIsContactModalOpen(true);
  };

  const handleOpenEdit = (contact) => {
    setEditingContact(contact);
    setIsContactModalOpen(true);
  };

  const handleSaveContact = async (formData) => {
    if (editingContact) {
      const id = editingContact._id || editingContact.id;
      const res = await api.updateContact(id, formData);
      if (res.success) {
        setContacts((prev) => prev.map((c) => ((c._id || c.id) === id ? res.data : c)));
        showToast(`Contact '${res.data.name}' updated successfully.`);
        // Refresh stats
        api.getStats().then((s) => s.success && setStats(s.data));
      }
    } else {
      const res = await api.createContact(formData);
      if (res.success) {
        setContacts((prev) => [res.data, ...prev]);
        showToast(`Registered '${res.data.name}' to emergency registry.`);
        // Refresh stats and categories
        api.getStats().then((s) => s.success && setStats(s.data));
        api.getCategories().then((c) => {
          if (c.success) {
            setCities(c.cities || []);
          }
        });
      }
    }
  };

  const handleDeleteContact = async (contact) => {
    const id = contact._id || contact.id;
    const confirmed = window.confirm(
      `Are you sure you want to permanently delete '${contact.name}' from the emergency directory?`
    );
    if (!confirmed) return;

    try {
      const res = await api.deleteContact(id);
      if (res.success) {
        setContacts((prev) => prev.filter((c) => (c._id || c.id) !== id));
        showToast(`Deleted '${contact.name}' from directory.`);
        api.getStats().then((s) => s.success && setStats(s.data));
      }
    } catch (err) {
      showToast(err.message || 'Failed to delete contact', 'error');
    }
  };

  const handleResetSeed = async () => {
    const confirmed = window.confirm(
      'This will reset the registry to default verified emergency response units. Proceed?'
    );
    if (!confirmed) return;

    try {
      const res = await api.resetSeed();
      if (res.success) {
        setContacts(res.data);
        showToast('Emergency contact registry restored to default state.');
        api.getStats().then((s) => s.success && setStats(s.data));
        setIsStatsOpen(false);
      }
    } catch (err) {
      showToast(err.message || 'Reset failed', 'error');
    }
  };

  const handleIncidentCreated = (newIncident) => {
    setIncidents((prev) => [newIncident, ...prev]);
    showToast(`SOS incident ${newIncident.incidentId} broadcasted.`);
  };

  const handleResetFilters = () => {
    setSearchQuery('');
    setSelectedCategory('All');
    setSelectedCity('All');
    setSelectedPriority('All');
    setShowOnlySaved(false);
  };

  return (
    <div style={{ minHeight: '100vh', display: 'flex', flexDirection: 'column', backgroundColor: 'var(--bg-main)' }}>
      
      {/* Toast Notification */}
      {toastMessage && (
        <div
          style={{
            position: 'fixed',
            bottom: '24px',
            right: '24px',
            zIndex: 9999,
            backgroundColor: toastMessage.type === 'error' ? 'var(--accent-red)' : 'var(--accent-green)',
            color: '#ffffff',
            padding: '0.85rem 1.25rem',
            borderRadius: '0.65rem',
            boxShadow: 'var(--shadow-lg)',
            display: 'flex',
            alignItems: 'center',
            gap: '0.6rem',
            fontWeight: 600,
            fontSize: '0.85rem',
          }}
        >
          {toastMessage.type === 'error' ? <AlertTriangle size={18} /> : <CheckCircle2 size={18} />}
          <span>{toastMessage.msg}</span>
        </div>
      )}

      {/* Top Navbar */}
      <Navbar
        onOpenAddModal={handleOpenAdd}
        onOpenSOSModal={() => setIsSOSOpen(true)}
        onOpenStatsModal={() => setIsStatsOpen(true)}
        onOpenInfoModal={() => setIsInfoOpen(true)}
        onOpenAuthModal={() => setIsAuthOpen(true)}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        theme={theme}
        toggleTheme={toggleTheme}
        dbStatus={dbStatus}
      />

      {/* Emergency Speed Dial Top Ribbon */}
      <QuickDialBanner />

      {/* Main Content Area */}
      <main style={{ flex: 1, padding: '2rem 0 4rem 0' }}>
        <div className="container">
          
          {loading ? (
            <div style={{ textAlign: 'center', padding: '5rem 0' }}>
              <Loader2 size={38} color="var(--accent-red)" className="animate-spin" style={{ margin: '0 auto 1rem auto' }} />
              <p style={{ color: 'var(--text-muted)', fontSize: '0.92rem' }}>Loading emergency systems and database records...</p>
            </div>
          ) : activeTab === 'login' ? (
            /* ================= DEDICATED LOGIN PAGE ================= */
            <LoginPage
              onLoginSuccess={() => {
                setActiveTab('dashboard');
                showToast('Authentication successful. Welcome to ResQLink!');
              }}
              onCancel={() => setActiveTab('dashboard')}
            />
          ) : activeTab === 'dashboard' ? (
            /* ================= DASHBOARD VIEW ================= */
            <DashboardView
              stats={stats}
              contacts={contacts}
              incidents={incidents}
              dbStatus={dbStatus}
              onOpenSOSModal={() => setIsSOSOpen(true)}
              onOpenAddModal={handleOpenAdd}
              onOpenInfoModal={() => setIsInfoOpen(true)}
              onNavigateDirectory={() => setActiveTab('directory')}
              onResetSeed={handleResetSeed}
              isAdmin={isAdmin}
            />
          ) : (
            /* ================= DIRECTORY VIEW ================= */
            <div>
              {/* Directory Header */}
              <div
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'space-between',
                  marginBottom: '1.75rem',
                  flexWrap: 'wrap',
                  gap: '1rem',
                }}
              >
                <div>
                  <h1 style={{ fontSize: '1.85rem', fontWeight: 800, color: 'var(--text-main)', letterSpacing: '-0.02em', margin: 0 }}>
                    Emergency Contacts & Services Directory
                  </h1>
                  <p style={{ fontSize: '0.88rem', color: 'var(--text-muted)', margin: '0.35rem 0 0 0' }}>
                    Verified index of public responders, hospitals, police stations, and helplines.
                  </p>
                </div>

                <div style={{ display: 'flex', alignItems: 'center', gap: '0.65rem' }}>
                  <button
                    onClick={() => setIsInfoOpen(true)}
                    className="btn btn-secondary btn-sm"
                  >
                    <FileText size={15} color="var(--accent-blue)" />
                    <span>Project Specs</span>
                  </button>
                  
                  {isAdmin && (
                    <button
                      onClick={handleOpenAdd}
                      className="btn btn-blue btn-sm"
                    >
                      <PlusCircle size={15} />
                      <span>Register Contact</span>
                    </button>
                  )}
                </div>
              </div>

              {/* Search & Multi-Criteria Filtering */}
              <FilterBar
                searchQuery={searchQuery}
                setSearchQuery={setSearchQuery}
                selectedCategory={selectedCategory}
                setSelectedCategory={setSelectedCategory}
                selectedCity={selectedCity}
                setSelectedCity={setSelectedCity}
                selectedPriority={selectedPriority}
                setSelectedPriority={setSelectedPriority}
                categories={categories}
                cities={cities}
                viewMode={viewMode}
                setViewMode={setViewMode}
                showOnlySaved={showOnlySaved}
                setShowOnlySaved={setShowOnlySaved}
                totalCount={filteredContacts.length}
                onResetFilters={handleResetFilters}
              />

              {filteredContacts.length === 0 ? (
                /* Empty State */
                <div
                  className="glass"
                  style={{
                    borderRadius: '1rem',
                    padding: '3rem 2rem',
                    textAlign: 'center',
                    border: '1px dashed var(--border-subtle)',
                  }}
                >
                  <ShieldAlert size={48} color="var(--text-dim)" style={{ margin: '0 auto 1rem auto' }} />
                  <h3 style={{ fontSize: '1.2rem', fontWeight: 700, color: 'var(--text-main)', marginBottom: '0.5rem' }}>
                    No matching emergency services found
                  </h3>
                  <p style={{ fontSize: '0.85rem', color: 'var(--text-muted)', maxWidth: '450px', margin: '0 auto 1.25rem auto' }}>
                    {showOnlySaved
                      ? "You don't have any contacts saved to your personal speed dial yet. Click the star on any card to bookmark it."
                      : 'Try modifying your search query or reset the filters to see all available responder units.'}
                  </p>
                  <div style={{ display: 'flex', justifyContent: 'center', gap: '0.75rem' }}>
                    <button onClick={handleResetFilters} className="btn btn-secondary">
                      Reset Filters
                    </button>
                    {isAdmin && (
                      <button onClick={handleOpenAdd} className="btn btn-primary">
                        <PlusCircle size={15} />
                        Add First Service
                      </button>
                    )}
                  </div>
                </div>
              ) : viewMode === 'grid' ? (
                /* Cards Grid View */
                <div
                  style={{
                    display: 'grid',
                    gridTemplateColumns: 'repeat(auto-fill, minmax(340px, 1fr))',
                    gap: '1.25rem',
                  }}
                >
                  {filteredContacts.map((contact) => (
                    <ContactCard
                      key={contact._id || contact.id}
                      contact={contact}
                      onEdit={handleOpenEdit}
                      onDelete={handleDeleteContact}
                    />
                  ))}
                </div>
              ) : (
                /* Table View */
                <ContactTable
                  contacts={filteredContacts}
                  onEdit={handleOpenEdit}
                  onDelete={handleDeleteContact}
                />
              )}
            </div>
          )}

        </div>
      </main>

      {/* Footer */}
      <footer style={{ borderTop: '1px solid var(--border-subtle)', backgroundColor: 'var(--banner-bg)', padding: '1.75rem 0', color: 'var(--text-muted)', fontSize: '0.8rem' }}>
        <div className="container" style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '1rem' }}>
          <div>
            <strong style={{ color: 'var(--text-main)' }}>ResQLink MERN System</strong> — Emergency Contact & Services Management
            <p style={{ fontSize: '0.72rem', margin: '0.2rem 0 0 0' }}>
              Built with MongoDB, Express.js, React.js, and Node.js. Includes Light/Dark theme and Live Dashboard.
            </p>
          </div>

          <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
            <span style={{ display: 'inline-flex', alignItems: 'center', gap: '0.35rem' }}>
              <span style={{ width: '8px', height: '8px', borderRadius: '50%', backgroundColor: 'var(--accent-green)' }} />
              API: 200 OK
            </span>
            <button
              onClick={() => setIsInfoOpen(true)}
              style={{ background: 'none', border: 'none', color: 'var(--accent-blue)', cursor: 'pointer', fontSize: '0.8rem' }}
            >
              System Documentation
            </button>
          </div>
        </div>
      </footer>

      {/* Modals */}
      <ContactModal
        isOpen={isContactModalOpen}
        onClose={() => {
          setIsContactModalOpen(false);
          setEditingContact(null);
        }}
        onSubmit={handleSaveContact}
        initialData={editingContact}
        categories={categories}
      />

      <SOSModal
        isOpen={isSOSOpen}
        onClose={() => setIsSOSOpen(false)}
        onIncidentCreated={handleIncidentCreated}
      />

      <StatsDashboard
        isOpen={isStatsOpen}
        onClose={() => setIsStatsOpen(false)}
        stats={stats}
        onResetSeed={handleResetSeed}
        dbStatus={dbStatus}
      />

      <ProjectInfoModal
        isOpen={isInfoOpen}
        onClose={() => setIsInfoOpen(false)}
      />

      <AuthModal
        isOpen={isAuthOpen}
        onClose={() => setIsAuthOpen(false)}
      />

    </div>
  );
};

export default function App() {
  return (
    <AuthProvider>
      <MainApp />
    </AuthProvider>
  );
}
