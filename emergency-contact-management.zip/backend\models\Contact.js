const mongoose = require('mongoose');

const contactSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: [true, 'Contact or service name is required'],
      trim: true,
    },
    service: {
      type: String,
      required: [true, 'Emergency service category is required'],
      enum: [
        'Police / Law Enforcement',
        'Ambulance / Medical Emergency',
        'Fire & Rescue Service',
        'Hospital & Emergency Room',
        'Disaster & Helpline',
        'Women & Child Helpline',
        'Blood Bank / Organ Bank',
        'Poison Control & Toxic Helpline',
        'Utility / Electric & Gas Emergency',
        'Personal / Family Emergency',
      ],
      default: 'Ambulance / Medical Emergency',
    },
    phone: {
      type: String,
      required: [true, 'Primary phone number is required'],
      trim: true,
    },
    alternatePhone: {
      type: String,
      trim: true,
      default: '',
    },
    location: {
      address: {
        type: String,
        required: [true, 'Location address is required'],
        trim: true,
      },
      city: {
        type: String,
        required: [true, 'City is required'],
        trim: true,
      },
      state: {
        type: String,
        default: '',
        trim: true,
      },
      zipCode: {
        type: String,
        default: '',
        trim: true,
      },
      coordinates: {
        lat: { type: Number, default: 0 },
        lng: { type: Number, default: 0 },
      },
    },
    priority: {
      type: String,
      enum: ['Critical', 'High', 'Standard'],
      default: 'High',
    },
    operatingHours: {
      type: String,
      default: '24/7 Available',
      trim: true,
    },
    email: {
      type: String,
      default: '',
      trim: true,
      lowercase: true,
    },
    description: {
      type: String,
      default: '',
      trim: true,
    },
    isVerified: {
      type: Boolean,
      default: true,
    },
    status: {
      type: String,
      enum: ['Active', 'Busy', 'Under Maintenance'],
      default: 'Active',
    },
    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
    },
  },
  {
    timestamps: true,
  }
);

// Text indexing for fast search
contactSchema.index({
  name: 'text',
  service: 'text',
  phone: 'text',
  'location.address': 'text',
  'location.city': 'text',
  description: 'text',
});

module.exports = mongoose.model('Contact', contactSchema);
