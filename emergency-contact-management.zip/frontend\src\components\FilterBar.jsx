import React from 'react';
import { Search, Filter, MapPin, AlertCircle, LayoutGrid, List, Star, RotateCcw } from 'lucide-react';

export const FilterBar = ({
  searchQuery,
  setSearchQuery,
  selectedCategory,
  setSelectedCategory,
  selectedCity,
  setSelectedCity,
  selectedPriority,
  setSelectedPriority,
  categories = [],
  cities = [],
  viewMode,
  setViewMode,
  showOnlySaved,
  setShowOnlySaved,
  totalCount,
  onResetFilters,
}) => {
  return (
    <div className="glass" style={{ borderRadius: '1rem', padding: '1.25rem', marginBottom: '1.75rem', border: '1px solid var(--border-subtle)' }}>
      
      {/* Top row: Search and View Mode */}
      <div style={{ display: 'flex', gap: '1rem', alignItems: 'center', flexWrap: 'wrap', marginBottom: '1rem' }}>
        
        {/* Main Search Input */}
        <div style={{ position: 'relative', flex: '1', minWidth: '280px' }}>
          <Search size={18} color="var(--text-muted)" style={{ position: 'absolute', left: '0.85rem', top: '50%', transform: 'translateY(-50%)' }} />
          <input
            type="text"
            className="input"
            style={{ paddingLeft: '2.5rem' }}
            placeholder="Search by name, service, phone number, city, or address..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              style={{
                position: 'absolute',
                right: '0.75rem',
                top: '50%',
                transform: 'translateY(-50%)',
                background: 'none',
                border: 'none',
                color: 'var(--text-muted)',
                cursor: 'pointer',
                fontSize: '0.85rem',
              }}
            >
              ✕
            </button>
          )}
        </div>

        {/* View Mode & Saved Filter */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
          
          <button
            onClick={() => setShowOnlySaved(!showOnlySaved)}
            className={`btn btn-sm ${showOnlySaved ? 'btn-primary' : 'btn-secondary'}`}
            title="Show my saved emergency contacts"
          >
            <Star size={14} fill={showOnlySaved ? '#ffffff' : 'none'} />
            <span>Speed Dial Only</span>
          </button>

          <div style={{ display: 'flex', backgroundColor: 'var(--bg-elevated)', borderRadius: '0.5rem', border: '1px solid var(--border-subtle)', padding: '2px' }}>
            <button
              onClick={() => setViewMode('grid')}
              className={`btn btn-sm ${viewMode === 'grid' ? 'btn-secondary' : 'btn-ghost'}`}
              style={{ padding: '0.35rem 0.6rem' }}
              title="Grid View"
            >
              <LayoutGrid size={15} color={viewMode === 'grid' ? 'var(--accent-blue)' : 'var(--text-muted)'} />
            </button>
            <button
              onClick={() => setViewMode('table')}
              className={`btn btn-sm ${viewMode === 'table' ? 'btn-secondary' : 'btn-ghost'}`}
              style={{ padding: '0.35rem 0.6rem' }}
              title="Table View"
            >
              <List size={15} color={viewMode === 'table' ? 'var(--accent-blue)' : 'var(--text-muted)'} />
            </button>
          </div>

        </div>

      </div>

      {/* Second Row: Dropdown Filters */}
      <div style={{ display: 'flex', gap: '0.75rem', alignItems: 'center', flexWrap: 'wrap' }}>
        
        {/* Service Category */}
        <div style={{ flex: '1', minWidth: '180px' }}>
          <select
            className="select"
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value)}
          >
            <option value="All">All Service Categories</option>
            {categories.map((cat) => (
              <option key={cat} value={cat}>
                {cat}
              </option>
            ))}
          </select>
        </div>

        {/* City Filter */}
        <div style={{ flex: '1', minWidth: '150px' }}>
          <select
            className="select"
            value={selectedCity}
            onChange={(e) => setSelectedCity(e.target.value)}
          >
            <option value="All">All Locations / Cities</option>
            {cities.map((city) => (
              <option key={city} value={city}>
                {city}
              </option>
            ))}
          </select>
        </div>

        {/* Priority Filter */}
        <div style={{ flex: '1', minWidth: '130px' }}>
          <select
            className="select"
            value={selectedPriority}
            onChange={(e) => setSelectedPriority(e.target.value)}
          >
            <option value="All">All Priorities</option>
            <option value="Critical">Critical (Immediate)</option>
            <option value="High">High</option>
            <option value="Standard">Standard</option>
          </select>
        </div>

        {/* Reset Filter Button */}
        <button
          onClick={onResetFilters}
          className="btn btn-secondary btn-sm"
          title="Reset all search and filters"
        >
          <RotateCcw size={14} />
          Reset
        </button>

        {/* Results Counter */}
        <div style={{ marginLeft: 'auto', fontSize: '0.8rem', color: 'var(--text-muted)' }}>
          Showing <strong style={{ color: 'var(--text-main)' }}>{totalCount}</strong> contact records
        </div>

      </div>

    </div>
  );
};
