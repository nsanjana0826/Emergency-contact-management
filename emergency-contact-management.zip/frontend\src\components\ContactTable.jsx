import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { Phone, Copy, Check, Star, Edit2, Trash2 } from 'lucide-react';

export const ContactTable = ({
  contacts = [],
  onEdit,
  onDelete,
}) => {
  const { user, isAdmin, toggleFavorite } = useAuth();
  const [copiedId, setCopiedId] = useState(null);

  const handleCopy = (id, phone, e) => {
    e.stopPropagation();
    navigator.clipboard.writeText(phone);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const getPriorityBadge = (priority) => {
    switch (priority) {
      case 'Critical':
        return <span className="badge badge-critical">Critical</span>;
      case 'High':
        return <span className="badge badge-high">High</span>;
      default:
        return <span className="badge badge-standard">Standard</span>;
    }
  };

  return (
    <div style={{ overflowX: 'auto', backgroundColor: 'var(--bg-card)', borderRadius: '1rem', border: '1px solid var(--border-subtle)', boxShadow: 'var(--shadow-sm)' }}>
      <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '0.82rem', textAlign: 'left' }}>
        <thead>
          <tr style={{ backgroundColor: 'var(--table-header)', borderBottom: '1px solid var(--border-subtle)', color: 'var(--text-muted)' }}>
            <th style={{ padding: '0.85rem 1rem' }}>Fav</th>
            <th style={{ padding: '0.85rem 1rem' }}>Name & Facility</th>
            <th style={{ padding: '0.85rem 1rem' }}>Service Category</th>
            <th style={{ padding: '0.85rem 1rem' }}>Emergency Phone</th>
            <th style={{ padding: '0.85rem 1rem' }}>City / Location</th>
            <th style={{ padding: '0.85rem 1rem' }}>Priority</th>
            <th style={{ padding: '0.85rem 1rem' }}>Hours</th>
            {isAdmin && <th style={{ padding: '0.85rem 1rem', textAlign: 'right' }}>Admin Actions</th>}
          </tr>
        </thead>
        <tbody>
          {contacts.map((contact) => {
            const id = contact._id || contact.id;
            const isFav = user?.savedContacts?.includes(id);

            return (
              <tr
                key={id}
                style={{
                  borderBottom: '1px solid var(--border-subtle)',
                  backgroundColor: contact.priority === 'Critical' ? 'rgba(239, 68, 68, 0.04)' : 'transparent',
                }}
              >
                {/* Star */}
                <td style={{ padding: '0.75rem 1rem' }}>
                  <button
                    onClick={() => toggleFavorite(id)}
                    style={{ background: 'none', border: 'none', cursor: 'pointer', color: isFav ? '#fbbf24' : 'var(--text-dim)' }}
                    title={isFav ? 'Remove favorite' : 'Bookmark to speed dial'}
                  >
                    <Star size={16} fill={isFav ? '#fbbf24' : 'none'} />
                  </button>
                </td>

                {/* Name */}
                <td style={{ padding: '0.75rem 1rem' }}>
                  <div style={{ fontWeight: 700, color: 'var(--text-main)' }}>{contact.name}</div>
                  {contact.description && (
                    <div style={{ fontSize: '0.72rem', color: 'var(--text-muted)', maxWidth: '240px', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                      {contact.description}
                    </div>
                  )}
                </td>

                {/* Service */}
                <td style={{ padding: '0.75rem 1rem', color: 'var(--text-main)' }}>
                  <span style={{ fontSize: '0.75rem', fontWeight: 600 }}>{contact.service}</span>
                </td>

                {/* Phone */}
                <td style={{ padding: '0.75rem 1rem' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '0.45rem' }}>
                    <span style={{ fontFamily: 'monospace', fontWeight: 700, color: 'var(--text-main)' }}>
                      {contact.phone}
                    </span>
                    <a
                      href={`tel:${contact.phone}`}
                      className="btn btn-ghost btn-sm"
                      style={{ padding: '0.2rem' }}
                      title="Call"
                    >
                      <Phone size={13} color="#10b981" />
                    </a>
                    <button
                      onClick={(e) => handleCopy(id, contact.phone, e)}
                      className="btn btn-ghost btn-sm"
                      style={{ padding: '0.2rem' }}
                      title="Copy"
                    >
                      {copiedId === id ? <Check size={13} color="#10b981" /> : <Copy size={13} color="var(--text-muted)" />}
                    </button>
                  </div>
                </td>

                {/* Location */}
                <td style={{ padding: '0.75rem 1rem', color: 'var(--text-main)' }}>
                  <div><strong>{contact.location?.city}</strong></div>
                  <div style={{ fontSize: '0.72rem', color: 'var(--text-muted)' }}>{contact.location?.address}</div>
                </td>

                {/* Priority */}
                <td style={{ padding: '0.75rem 1rem' }}>
                  {getPriorityBadge(contact.priority)}
                </td>

                {/* Hours */}
                <td style={{ padding: '0.75rem 1rem', color: 'var(--text-muted)', fontSize: '0.75rem' }}>
                  {contact.operatingHours || '24/7'}
                </td>

                {/* Admin Actions */}
                {isAdmin && (
                  <td style={{ padding: '0.75rem 1rem', textAlign: 'right' }}>
                    <div style={{ display: 'inline-flex', gap: '0.35rem' }}>
                      <button
                        onClick={() => onEdit(contact)}
                        className="btn btn-ghost btn-sm"
                        style={{ padding: '0.25rem' }}
                        title="Edit"
                      >
                        <Edit2 size={14} color="var(--accent-blue)" />
                      </button>
                      <button
                        onClick={() => onDelete(contact)}
                        className="btn btn-ghost btn-sm"
                        style={{ padding: '0.25rem' }}
                        title="Delete"
                      >
                        <Trash2 size={14} color="var(--accent-red)" />
                      </button>
                    </div>
                  </td>
                )}
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
};
