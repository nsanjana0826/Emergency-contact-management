const express = require('express');
const router = express.Router();
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const {
  findUserByEmail,
  findUserById,
  createUser,
  toggleSaveContact,
} = require('../services/dataService');
const { verifyToken } = require('../middleware/authMiddleware');

const generateToken = (userId, role) => {
  const secret = process.env.JWT_SECRET || 'emergency_jwt_secret_token_key_2026_super_secure';
  return jwt.sign({ id: userId, role }, secret, { expiresIn: '7d' });
};

// Register new user
router.post('/register', async (req, res) => {
  try {
    const { name, email, password, role, phone, location } = req.body;

    if (!name || !email || !password) {
      return res.status(400).json({
        success: false,
        message: 'Name, email, and password are required fields.',
      });
    }

    if (password.length < 6) {
      return res.status(400).json({
        success: false,
        message: 'Password must be at least 6 characters long.',
      });
    }

    const existingUser = await findUserByEmail(email);
    if (existingUser) {
      return res.status(409).json({
        success: false,
        message: 'An account with this email address already exists.',
      });
    }

    const newUser = await createUser({
      name,
      email,
      password,
      role: role === 'admin' ? 'admin' : 'user',
      phone: phone || '',
      location: location || 'General',
    });

    const token = generateToken(newUser._id || newUser.id, newUser.role);

    res.status(201).json({
      success: true,
      message: 'Account registered successfully.',
      token,
      user: {
        id: newUser._id || newUser.id,
        name: newUser.name,
        email: newUser.email,
        role: newUser.role,
        phone: newUser.phone,
        location: newUser.location,
        savedContacts: newUser.savedContacts || [],
      },
    });
  } catch (err) {
    console.error('Registration error:', err);
    res.status(500).json({
      success: false,
      message: 'Server error during registration: ' + err.message,
    });
  }
});

// Login
router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({
        success: false,
        message: 'Both email and password are required.',
      });
    }

    const user = await findUserByEmail(email);
    if (!user) {
      return res.status(401).json({
        success: false,
        message: 'Invalid credentials. User not found with this email.',
      });
    }

    let isMatch = false;
    if (typeof user.comparePassword === 'function') {
      isMatch = await user.comparePassword(password);
    } else {
      isMatch = await bcrypt.compare(password, user.password);
    }

    if (!isMatch) {
      return res.status(401).json({
        success: false,
        message: 'Invalid credentials. Password does not match.',
      });
    }

    const token = generateToken(user._id || user.id, user.role);

    res.json({
      success: true,
      message: `Welcome back, ${user.name}!`,
      token,
      user: {
        id: user._id || user.id,
        name: user.name,
        email: user.email,
        role: user.role,
        phone: user.phone || '',
        location: user.location || '',
        savedContacts: user.savedContacts || [],
      },
    });
  } catch (err) {
    console.error('Login error:', err);
    res.status(500).json({
      success: false,
      message: 'Server error during login: ' + err.message,
    });
  }
});

// Get current user profile
router.get('/me', verifyToken, async (req, res) => {
  try {
    const user = await findUserById(req.user._id || req.user.id);
    if (!user) {
      return res.status(404).json({ success: false, message: 'User not found' });
    }
    res.json({
      success: true,
      user: {
        id: user._id || user.id,
        name: user.name,
        email: user.email,
        role: user.role,
        phone: user.phone || '',
        location: user.location || '',
        savedContacts: user.savedContacts || [],
      },
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// Toggle bookmark / saved contact
router.post('/toggle-save/:contactId', verifyToken, async (req, res) => {
  try {
    const { contactId } = req.params;
    const userId = req.user._id || req.user.id;
    const result = await toggleSaveContact(userId, contactId);

    if (!result) {
      return res.status(404).json({ success: false, message: 'User not found' });
    }

    res.json({
      success: true,
      saved: result.saved,
      savedContacts: result.savedContacts,
      message: result.saved ? 'Contact added to personal emergency speed dial.' : 'Contact removed from personal speed dial.',
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// Demo accounts endpoint for easy one-click evaluator login
router.get('/demo-accounts', (req, res) => {
  res.json({
    admin: {
      email: 'admin@emergency.org',
      password: 'AdminPassword123!',
      role: 'admin',
      label: 'System Admin (Full CRUD Access)',
    },
    user: {
      email: 'user@emergency.org',
      password: 'UserPassword123!',
      role: 'user',
      label: 'Citizen / Standard User (View & Speed Dial)',
    },
  });
});

module.exports = router;
