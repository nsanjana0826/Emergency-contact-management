import React from 'react';
import { useAuth } from '../context/AuthContext';
import {
  BarChart2,
  X,
  Shield,
  Activity,
  Clock,
  MapPin,
  RefreshCw,
  Server,
  Database,
  CheckCircle,
} from 'lucide-react';

export const StatsDashboard = ({
  isOpen,
  onClose,
  stats,
  onResetSeed,
  dbStatus,
}) => {
  const { isAdmin } = useAuth();

  if (!isOpen || !stats) return null;

  const total = stats.totalContacts || 0;
  const byService = stats.byService || {};
  const byPriority = stats.byPriority || { Critical: 0, High: 0, Standard: 0 };

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-content" style={{ maxWidth: '780px' }} onClick={(e) => e.stopPropagation()}>
        
        {/* Header */}
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', borderBottom: '1px solid #1e293b', paddingBottom: '0.85rem', marginBottom: '1.25rem' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.65rem' }}>
            <div
              style={{
                width: '36px',
                height: '36px',
                borderRadius: '8px',
                backgroundColor: 'rgba(59, 130, 246, 0.2)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
              }}
            >
              <BarChart2 size={20} color="#3b82f6" />
            </div>
            <div>
              <h3 style={{ fontSize: '1.25rem', fontWeight: 800, color: '#f8fafc', margin: 0 }}>
                Emergency System Metrics & Analytics
              </h3>
              <p style={{ fontSize: '0.75rem', color: '#94a3b8', margin: 0 }}>
                Live response capacity and operational service distribution
              </p>
            </div>
          </div>

          <button onClick={onClose} className="btn btn-ghost btn-sm" style={{ padding: '0.25rem' }}>
            <X size={20} />
          </button>
        </div>

        {/* 4 Top KPI Cards */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(150px, 1fr))', gap: '0.85rem', marginBottom: '1.5rem' }}>
          
          <div style={{ backgroundColor: '#0f172a', border: '1px solid #1e293b', borderRadius: '0.75rem', padding: '1rem' }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '0.4rem' }}>
              <span style={{ fontSize: '0.72rem', color: '#94a3b8', fontWeight: 600, textTransform: 'uppercase' }}>Total Services</span>
              <Shield size={16} color="#38bdf8" />
            </div>
            <div style={{ fontSize: '1.8rem', fontWeight: 800, color: '#f8fafc' }}>{total}</div>
            <span style={{ fontSize: '0.7rem', color: '#10b981' }}>● Active in directory</span>
          </div>

          <div style={{ backgroundColor: '#0f172a', border: '1px solid #1e293b', borderRadius: '0.75rem', padding: '1rem' }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '0.4rem' }}>
              <span style={{ fontSize: '0.72rem', color: '#94a3b8', fontWeight: 600, textTransform: 'uppercase' }}>24/7 Responders</span>
              <Clock size={16} color="#10b981" />
            </div>
            <div style={{ fontSize: '1.8rem', fontWeight: 800, color: '#34d399' }}>{stats.available247 || 0}</div>
            <span style={{ fontSize: '0.7rem', color: '#94a3b8' }}>Always reachable</span>
          </div>

          <div style={{ backgroundColor: '#0f172a', border: '1px solid #1e293b', borderRadius: '0.75rem', padding: '1rem' }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '0.4rem' }}>
              <span style={{ fontSize: '0.72rem', color: '#94a3b8', fontWeight: 600, textTransform: 'uppercase' }}>Critical Units</span>
              <Activity size={16} color="#ef4444" />
            </div>
            <div style={{ fontSize: '1.8rem', fontWeight: 800, color: '#f87171' }}>{byPriority.Critical || 0}</div>
            <span style={{ fontSize: '0.7rem', color: '#ef4444' }}>Immediate triage</span>
          </div>

          <div style={{ backgroundColor: '#0f172a', border: '1px solid #1e293b', borderRadius: '0.75rem', padding: '1rem' }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '0.4rem' }}>
              <span style={{ fontSize: '0.72rem', color: '#94a3b8', fontWeight: 600, textTransform: 'uppercase' }}>Cities Covered</span>
              <MapPin size={16} color="#f59e0b" />
            </div>
            <div style={{ fontSize: '1.8rem', fontWeight: 800, color: '#fbbf24' }}>{stats.totalCities || 0}</div>
            <span style={{ fontSize: '0.7rem', color: '#94a3b8' }}>Territorial zones</span>
          </div>

        </div>

        {/* Breakdown by Service Category */}
        <div style={{ backgroundColor: '#0f172a', border: '1px solid #1e293b', borderRadius: '0.75rem', padding: '1.25rem', marginBottom: '1.25rem' }}>
          <h4 style={{ fontSize: '0.85rem', fontWeight: 700, color: '#e2e8f0', textTransform: 'uppercase', letterSpacing: '0.04em', marginBottom: '1rem' }}>
            Services Distribution by Category
          </h4>

          <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
            {Object.entries(byService).map(([category, count]) => {
              const pct = total > 0 ? Math.round((count / total) * 100) : 0;
              return (
                <div key={category}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.78rem', marginBottom: '0.25rem' }}>
                    <span style={{ color: '#cbd5e1', fontWeight: 600 }}>{category}</span>
                    <span style={{ color: '#94a3b8' }}>
                      {count} {count === 1 ? 'service' : 'services'} ({pct}%)
                    </span>
                  </div>
                  <div style={{ width: '100%', height: '8px', backgroundColor: '#1e293b', borderRadius: '4px', overflow: 'hidden' }}>
                    <div
                      style={{
                        height: '100%',
                        width: `${pct}%`,
                        backgroundColor:
                          category.includes('Medical') || category.includes('Ambulance')
                            ? '#ef4444'
                            : category.includes('Police')
                            ? '#3b82f6'
                            : category.includes('Fire')
                            ? '#f97316'
                            : category.includes('Hospital')
                            ? '#10b981'
                            : '#8b5cf6',
                        borderRadius: '4px',
                        transition: 'width 0.4s ease',
                      }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Database & System Architecture Status */}
        <div
          style={{
            backgroundColor: '#090d16',
            border: '1px solid #1e293b',
            borderRadius: '0.75rem',
            padding: '1rem',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            flexWrap: 'wrap',
            gap: '0.75rem',
          }}
        >
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
            <Database size={20} color="#38bdf8" />
            <div>
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
                <span style={{ fontSize: '0.82rem', fontWeight: 700, color: '#f8fafc' }}>
                  Database Engine:
                </span>
                <span className={`badge ${dbStatus?.isConnected ? 'badge-green' : 'badge-standard'}`} style={{ fontSize: '0.65rem' }}>
                  {dbStatus?.isConnected ? 'MongoDB Active' : 'Resilient Mongoose Engine'}
                </span>
              </div>
              <p style={{ fontSize: '0.72rem', color: '#64748b', margin: 0 }}>
                {dbStatus?.mongoUri}
              </p>
            </div>
          </div>

          {isAdmin && (
            <button
              onClick={onResetSeed}
              className="btn btn-secondary btn-sm"
              title="Reset records to default emergency seed dataset"
            >
              <RefreshCw size={13} />
              <span>Reset & Re-seed Dataset</span>
            </button>
          )}
        </div>

      </div>
    </div>
  );
};
