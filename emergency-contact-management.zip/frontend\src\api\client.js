const API_BASE = '/api';

const request = async (url, options = {}) => {
  const token = localStorage.getItem('emergency_token');
  const headers = {
    'Content-Type': 'application/json',
    ...(options.headers || {}),
  };

  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }

  const response = await fetch(`${API_BASE}${url}`, {
    ...options,
    headers,
  });

  const data = await response.json().catch(() => ({}));

  if (!response.ok) {
    const errorMsg = data.message || `Request failed with status ${response.status}`;
    const err = new Error(errorMsg);
    err.status = response.status;
    err.data = data;
    throw err;
  }

  return data;
};

export const api = {
  // Auth
  login: (credentials) => request('/auth/login', { method: 'POST', body: JSON.stringify(credentials) }),
  register: (userData) => request('/auth/register', { method: 'POST', body: JSON.stringify(userData) }),
  getMe: () => request('/auth/me'),
  getDemoAccounts: () => request('/auth/demo-accounts'),
  toggleSaveContact: (contactId) => request(`/auth/toggle-save/${contactId}`, { method: 'POST' }),

  // Contacts
  getContacts: (params = {}) => {
    const query = new URLSearchParams();
    Object.entries(params).forEach(([key, val]) => {
      if (val !== undefined && val !== null && val !== '') {
        query.append(key, val);
      }
    });
    const queryString = query.toString();
    return request(`/contacts${queryString ? `?${queryString}` : ''}`);
  },
  getContactById: (id) => request(`/contacts/${id}`),
  createContact: (contactData) => request('/contacts', { method: 'POST', body: JSON.stringify(contactData) }),
  updateContact: (id, contactData) => request(`/contacts/${id}`, { method: 'PUT', body: JSON.stringify(contactData) }),
  deleteContact: (id) => request(`/contacts/${id}`, { method: 'DELETE' }),
  getStats: () => request('/contacts/stats/overview'),
  getCategories: () => request('/contacts/meta/categories'),
  resetSeed: () => request('/contacts/seed/reset', { method: 'POST' }),

  // SOS & Emergency
  triggerSOS: (sosData) => request('/emergency/sos', { method: 'POST', body: JSON.stringify(sosData) }),
  getIncidents: () => request('/emergency/incidents'),

  // System
  getHealth: () => request('/health'),
  getProjectInfo: () => request('/project-info'),
};
