import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import {
  Phone,
  MapPin,
  Clock,
  Shield,
  Ambulance,
  Flame,
  Hospital,
  HeartHandshake,
  Wrench,
  AlertTriangle,
  Star,
  Copy,
  Check,
  Edit2,
  Trash2,
} from 'lucide-react';

export const ContactCard = ({
  contact,
  onEdit,
  onDelete,
}) => {
  const { user, isAdmin, toggleFavorite } = useAuth();
  const [copied, setCopied] = useState(false);
  const [savingFavorite, setSavingFavorite] = useState(false);

  const isFavorite = user?.savedContacts?.includes(contact._id || contact.id);

  // Icon and theme based on service
  const getServiceMeta = (serviceName) => {
    const s = (serviceName || '').toLowerCase();
    if (s.includes('police') || s.includes('law')) {
      return { icon: Shield, color: '#3b82f6', badgeClass: 'badge-standard' };
    }
    if (s.includes('ambulance') || s.includes('medical')) {
      return { icon: Ambulance, color: '#ef4444', badgeClass: 'badge-critical' };
    }
    if (s.includes('fire')) {
      return { icon: Flame, color: '#f97316', badgeClass: 'badge-high' };
    }
    if (s.includes('hospital')) {
      return { icon: Hospital, color: '#10b981', badgeClass: 'badge-green' };
    }
    if (s.includes('women') || s.includes('child')) {
      return { icon: HeartHandshake, color: '#ec4899', badgeClass: 'badge-purple' };
    }
    if (s.includes('utility')) {
      return { icon: Wrench, color: '#eab308', badgeClass: 'badge-high' };
    }
    return { icon: AlertTriangle, color: '#8b5cf6', badgeClass: 'badge-purple' };
  };

  const meta = getServiceMeta(contact.service);
  const IconComponent = meta.icon;

  const handleCopyPhone = (e) => {
    e.stopPropagation();
    navigator.clipboard.writeText(contact.phone);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleToggleStar = async (e) => {
    e.stopPropagation();
    if (!user) {
      alert('Please sign in or use one of the demo accounts to bookmark emergency speed dial contacts.');
      return;
    }
    setSavingFavorite(true);
    await toggleFavorite(contact._id || contact.id);
    setSavingFavorite(false);
  };

  const getPriorityBadge = (priority) => {
    switch (priority) {
      case 'Critical':
        return <span className="badge badge-critical">🚨 Critical</span>;
      case 'High':
        return <span className="badge badge-high">⚠️ High</span>;
      default:
        return <span className="badge badge-standard">ℹ️ Standard</span>;
    }
  };

  return (
    <div
      className="glass"
      style={{
        borderRadius: '1rem',
        padding: '1.4rem',
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'space-between',
        transition: 'transform 0.2s ease, box-shadow 0.2s ease',
        border: contact.priority === 'Critical' ? '1px solid rgba(239, 68, 68, 0.35)' : '1px solid var(--border-subtle)',
        backgroundColor: 'var(--bg-card)',
        boxShadow: 'var(--shadow-sm)',
      }}
    >
      <div>
        {/* Header: Service Badge, Priority, and Star */}
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '0.9rem', gap: '0.5rem' }}>
          
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.45rem', flexWrap: 'wrap' }}>
            <span
              style={{
                fontSize: '0.72rem',
                fontWeight: 700,
                color: meta.color,
                backgroundColor: `${meta.color}15`,
                padding: '0.2rem 0.6rem',
                borderRadius: '6px',
                border: `1px solid ${meta.color}35`,
                display: 'inline-flex',
                alignItems: 'center',
                gap: '0.3rem',
              }}
            >
              <IconComponent size={13} color={meta.color} />
              {contact.service}
            </span>
            {getPriorityBadge(contact.priority)}
          </div>

          {/* Star Bookmark */}
          <button
            onClick={handleToggleStar}
            disabled={savingFavorite}
            style={{
              background: 'none',
              border: 'none',
              cursor: 'pointer',
              color: isFavorite ? '#fbbf24' : 'var(--text-dim)',
              padding: '0.2rem',
              display: 'flex',
              alignItems: 'center',
            }}
            title={isFavorite ? 'Remove from speed dial' : 'Save to my speed dial'}
          >
            <Star size={18} fill={isFavorite ? '#fbbf24' : 'none'} />
          </button>

        </div>

        {/* Contact / Facility Name */}
        <h3 style={{ fontSize: '1.15rem', fontWeight: 800, color: 'var(--text-main)', marginBottom: '0.5rem', lineHeight: 1.3 }}>
          {contact.name}
        </h3>

        {/* Description */}
        {contact.description && (
          <p style={{ fontSize: '0.82rem', color: 'var(--text-muted)', marginBottom: '1rem', lineHeight: 1.45 }}>
            {contact.description}
          </p>
        )}

        {/* Location & Availability Information */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '0.45rem', marginBottom: '1.25rem' }}>
          
          <div style={{ display: 'flex', alignItems: 'flex-start', gap: '0.5rem', fontSize: '0.8rem', color: 'var(--text-main)' }}>
            <MapPin size={16} color="var(--accent-blue)" style={{ marginTop: '2px', flexShrink: 0 }} />
            <span>
              <strong>{contact.location?.city || 'Unknown City'}</strong>: {contact.location?.address}
              {contact.location?.state ? `, ${contact.location.state}` : ''}
            </span>
          </div>

          <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', fontSize: '0.78rem', color: 'var(--text-muted)' }}>
            <Clock size={15} color="var(--accent-green)" style={{ flexShrink: 0 }} />
            <span>{contact.operatingHours || '24/7 Available'}</span>
            {contact.status && (
              <span
                style={{
                  marginLeft: 'auto',
                  fontSize: '0.68rem',
                  fontWeight: 600,
                  color: contact.status === 'Active' ? 'var(--accent-green)' : 'var(--accent-amber)',
                }}
              >
                ● {contact.status}
              </span>
            )}
          </div>

        </div>

      </div>

      {/* Action Footer: Phone Number & Controls */}
      <div style={{ borderTop: '1px solid var(--border-subtle)', paddingTop: '1rem' }}>
        
        {/* Primary Phone Box */}
        <div
          style={{
            backgroundColor: 'var(--box-inner-bg)',
            border: '1px solid var(--border-subtle)',
            borderRadius: '0.5rem',
            padding: '0.65rem 0.85rem',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            marginBottom: '0.75rem',
          }}
        >
          <div>
            <span style={{ fontSize: '0.65rem', color: 'var(--text-dim)', textTransform: 'uppercase', letterSpacing: '0.05em', display: 'block' }}>
              EMERGENCY DIAL LINE
            </span>
            <span style={{ fontSize: '1.1rem', fontWeight: 800, color: 'var(--text-main)', letterSpacing: '0.02em' }}>
              {contact.phone}
            </span>
          </div>

          <div style={{ display: 'flex', alignItems: 'center', gap: '0.35rem' }}>
            <a
              href={`tel:${contact.phone}`}
              className="btn btn-primary btn-sm"
              style={{ padding: '0.35rem 0.75rem' }}
              title="Call immediately"
            >
              <Phone size={14} />
              <span>Call</span>
            </a>

            <button
              onClick={handleCopyPhone}
              className="btn btn-secondary btn-sm"
              style={{ padding: '0.35rem 0.5rem' }}
              title="Copy phone number"
            >
              {copied ? <Check size={14} color="#10b981" /> : <Copy size={14} />}
            </button>
          </div>
        </div>

        {/* Alternate phone if exists */}
        {contact.alternatePhone && (
          <div style={{ fontSize: '0.74rem', color: 'var(--text-dim)', marginBottom: '0.65rem' }}>
            Alt Line: <span style={{ color: 'var(--text-muted)' }}>{contact.alternatePhone}</span>
          </div>
        )}

        {/* Admin CRUD Actions: Edit & Delete */}
        {isAdmin && (
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'flex-end', gap: '0.5rem', marginTop: '0.5rem' }}>
            <button
              onClick={() => onEdit(contact)}
              className="btn btn-sm btn-secondary"
              style={{ fontSize: '0.75rem' }}
            >
              <Edit2 size={13} color="var(--accent-blue)" />
              <span>Edit</span>
            </button>
            <button
              onClick={() => onDelete(contact)}
              className="btn btn-sm btn-danger-ghost"
              style={{ fontSize: '0.75rem' }}
            >
              <Trash2 size={13} color="var(--accent-red)" />
              <span>Delete</span>
            </button>
          </div>
        )}

      </div>
    </div>
  );
};
