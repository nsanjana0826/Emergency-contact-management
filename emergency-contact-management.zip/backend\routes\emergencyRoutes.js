const express = require('express');
const router = express.Router();
const { getContacts } = require('../services/dataService');
const { optionalAuth } = require('../middleware/authMiddleware');

// In-Memory incident logs array with realistic initial incidents
let incidentLogs = [
  {
    incidentId: 'INC-842910',
    timestamp: new Date(Date.now() - 15 * 60000).toISOString(),
    caller: 'Sarah Jenkins',
    phone: '+1-555-019-3321',
    emergencyType: 'Ambulance / Medical Emergency',
    coordinates: { lat: 40.7128, lng: -74.006 },
    message: 'Pedestrian involved in vehicle collision. Suspected concussion.',
    dispatchedContacts: [
      { name: 'St. Jude Apex Trauma & Emergency Hospital', service: 'Hospital & Emergency Room', phone: '+1-800-987-6543' },
      { name: 'National Emergency Response Service', service: 'Ambulance / Medical Emergency', phone: '112' }
    ],
    status: 'EN_ROUTE',
    severity: 'High',
  },
  {
    incidentId: 'INC-731204',
    timestamp: new Date(Date.now() - 48 * 60000).toISOString(),
    caller: 'Marcus Vance',
    phone: '+1-555-014-9988',
    emergencyType: 'Fire & Rescue Service',
    coordinates: { lat: 34.0522, lng: -118.2437 },
    message: 'Smoke reported in commercial warehouse basement sector 4.',
    dispatchedContacts: [
      { name: 'City Fire & Disaster Rescue Service', service: 'Fire & Rescue Service', phone: '101' }
    ],
    status: 'CONTAINED',
    severity: 'Critical',
  },
  {
    incidentId: 'INC-619852',
    timestamp: new Date(Date.now() - 120 * 60000).toISOString(),
    caller: 'Citizen Dispatch',
    phone: '100',
    emergencyType: 'Police / Law Enforcement',
    coordinates: { lat: 40.7589, lng: -73.9851 },
    message: 'Suspicious vehicle blocking high-speed hospital transit lane.',
    dispatchedContacts: [
      { name: 'Metropolitan Police Central Command', service: 'Police / Law Enforcement', phone: '100' }
    ],
    status: 'RESOLVED',
    severity: 'Standard',
  }
];

// Get recent incident reports for the dashboard
router.get('/incidents', (req, res) => {
  res.json({
    success: true,
    count: incidentLogs.length,
    data: incidentLogs,
  });
});

// Trigger simulated SOS Emergency Alert
router.post('/sos', optionalAuth, async (req, res) => {
  try {
    const { emergencyType, coordinates, customMessage, userPhone, callerName } = req.body;

    const caller = req.user ? req.user.name : callerName || 'Anonymous Citizen';
    const phone = req.user ? req.user.phone : userPhone || 'Unknown Phone';

    // Find nearest / appropriate contacts for this emergency type
    const allContacts = await getContacts({});
    const relevantServices = allContacts.filter((c) => {
      if (!emergencyType) return c.priority === 'Critical';
      return (
        c.service.toLowerCase().includes((emergencyType || '').toLowerCase()) ||
        c.priority === 'Critical'
      );
    });

    const alertLog = {
      incidentId: 'INC-' + Math.floor(100000 + Math.random() * 900000),
      timestamp: new Date().toISOString(),
      caller,
      phone,
      emergencyType: emergencyType || 'Critical Distress (General)',
      coordinates: coordinates || { lat: 28.6139, lng: 77.209 },
      message: customMessage || 'URGENT: Caller requires immediate emergency response assistance.',
      dispatchedContacts: relevantServices.slice(0, 3).map((c) => ({
        id: c._id || c.id,
        name: c.name,
        service: c.service,
        phone: c.phone,
      })),
      status: 'DISPATCH_BROADCASTED',
      severity: 'Critical',
    };

    incidentLogs.unshift(alertLog);
    if (incidentLogs.length > 20) {
      incidentLogs.pop();
    }

    res.json({
      success: true,
      message: '🚨 Emergency SOS Broadcast generated and sent to responder command centers.',
      alert: alertLog,
    });
  } catch (err) {
    res.status(500).json({
      success: false,
      message: 'SOS trigger failed: ' + err.message,
    });
  }
});

module.exports = router;
