import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import {
  ShieldAlert,
  PlusCircle,
  BarChart2,
  Info,
  UserCheck,
  LogIn,
  LogOut,
  Radio,
  Sparkles,
  Sun,
  Moon,
  LayoutDashboard,
  BookOpen,
  Download,
} from 'lucide-react';

export const Navbar = ({
  onOpenAddModal,
  onOpenSOSModal,
  onOpenInfoModal,
  onOpenAuthModal,
  activeTab,
  setActiveTab,
  theme,
  toggleTheme,
  dbStatus,
}) => {
  const { user, isAdmin, logout, quickLogin } = useAuth();
  const [showUserMenu, setShowUserMenu] = useState(false);

  return (
    <header className="glass" style={{ position: 'sticky', top: 0, zIndex: 100, borderBottom: '1px solid var(--border-subtle)' }}>
      <div className="container" style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', height: '70px', padding: '0 1rem' }}>
        
        {/* Brand */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', cursor: 'pointer' }} onClick={() => setActiveTab('dashboard')}>
          <div style={{
            width: '42px',
            height: '42px',
            borderRadius: '10px',
            background: 'linear-gradient(135deg, #ef4444 0%, #b91c1c 100%)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            boxShadow: '0 0 15px rgba(239, 68, 68, 0.4)'
          }}>
            <ShieldAlert size={24} color="#ffffff" />
          </div>
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
              <span style={{ fontSize: '1.18rem', fontWeight: 800, letterSpacing: '-0.02em', color: 'var(--text-main)' }}>
                ResQ<span style={{ color: 'var(--accent-red)' }}>Link</span>
              </span>
              <span style={{
                fontSize: '0.65rem',
                backgroundColor: 'rgba(239, 68, 68, 0.15)',
                color: 'var(--accent-red)',
                padding: '0.1rem 0.4rem',
                borderRadius: '4px',
                fontWeight: 700,
                border: '1px solid rgba(239, 68, 68, 0.3)'
              }}>
                MERN 24/7
              </span>
            </div>
            <p style={{ fontSize: '0.72rem', color: 'var(--text-muted)', margin: 0, lineHeight: 1 }}>
              Emergency Services & Contact Management
            </p>
          </div>
        </div>

        {/* Center Navigation Links: Dashboard vs Directory */}
        <nav style={{ display: 'flex', alignItems: 'center', gap: '0.4rem', backgroundColor: 'var(--bg-elevated)', padding: '4px', borderRadius: '0.6rem', border: '1px solid var(--border-subtle)' }}>
          <button
            className={`btn btn-sm ${activeTab === 'dashboard' ? 'btn-secondary' : 'btn-ghost'}`}
            style={{
              color: activeTab === 'dashboard' ? 'var(--accent-blue)' : 'var(--text-muted)',
              fontWeight: activeTab === 'dashboard' ? 700 : 500,
              backgroundColor: activeTab === 'dashboard' ? 'var(--bg-card)' : 'transparent',
              boxShadow: activeTab === 'dashboard' ? 'var(--shadow-sm)' : 'none',
            }}
            onClick={() => setActiveTab('dashboard')}
          >
            <LayoutDashboard size={15} />
            <span>Dashboard</span>
          </button>

          <button
            className={`btn btn-sm ${activeTab === 'directory' ? 'btn-secondary' : 'btn-ghost'}`}
            style={{
              color: activeTab === 'directory' ? 'var(--accent-blue)' : 'var(--text-muted)',
              fontWeight: activeTab === 'directory' ? 700 : 500,
              backgroundColor: activeTab === 'directory' ? 'var(--bg-card)' : 'transparent',
              boxShadow: activeTab === 'directory' ? 'var(--shadow-sm)' : 'none',
            }}
            onClick={() => setActiveTab('directory')}
          >
            <BookOpen size={15} />
            <span>Emergency Directory</span>
          </button>

          <button
            className="btn btn-sm btn-ghost"
            onClick={onOpenInfoModal}
            title="Project Architecture & Objectives"
          >
            <Info size={15} />
            <span>About</span>
          </button>
        </nav>

        {/* Actions & User Controls */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.65rem' }}>
          
          {/* Download ZIP Archive Button */}
          <a
            href="http://localhost:5000/api/download-zip"
            download="emergency-contact-management.zip"
            className="btn btn-secondary btn-sm"
            style={{ padding: '0.45rem 0.75rem', gap: '0.4rem', textDecoration: 'none' }}
            title="Download full project zip archive"
          >
            <Download size={14} color="var(--accent-blue)" />
            <span>Download ZIP</span>
          </a>

          {/* Light / Dark Theme Switcher */}
          <button
            onClick={toggleTheme}
            className="btn btn-secondary btn-sm"
            style={{ padding: '0.45rem', borderRadius: '0.5rem' }}
            title={theme === 'dark' ? 'Switch to Light Theme' : 'Switch to Dark Theme'}
            aria-label="Toggle theme"
          >
            {theme === 'dark' ? (
              <Sun size={17} color="#f59e0b" />
            ) : (
              <Moon size={17} color="#6366f1" />
            )}
          </button>

          {/* Quick SOS Trigger Button */}
          <button
            onClick={onOpenSOSModal}
            className="btn btn-primary pulse-emergency"
            style={{ fontWeight: 700, letterSpacing: '0.02em', padding: '0.45rem 0.95rem' }}
          >
            <Radio size={16} />
            <span>SOS</span>
          </button>

          {/* Add Contact Button (Visible for Admin) */}
          {isAdmin && (
            <button
              onClick={onOpenAddModal}
              className="btn btn-blue"
              style={{ padding: '0.45rem 0.85rem' }}
            >
              <PlusCircle size={16} />
              <span>Add</span>
            </button>
          )}

          {/* Auth State & Role Switcher */}
          {user ? (
            <div style={{ position: 'relative' }}>
              <button
                onClick={() => setShowUserMenu(!showUserMenu)}
                className="btn btn-secondary"
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '0.5rem',
                  padding: '0.42rem 0.8rem',
                  borderColor: isAdmin ? 'var(--accent-red)' : 'var(--accent-blue)',
                }}
              >
                <div style={{
                  width: '8px',
                  height: '8px',
                  borderRadius: '50%',
                  backgroundColor: isAdmin ? 'var(--accent-red)' : 'var(--accent-green)',
                }} />
                <span style={{ fontSize: '0.82rem', fontWeight: 600 }}>{user.name.split(' ')[0]}</span>
                <span className={`badge ${isAdmin ? 'badge-critical' : 'badge-standard'}`} style={{ fontSize: '0.65rem' }}>
                  {user.role}
                </span>
              </button>

              {showUserMenu && (
                <div
                  className="glass"
                  style={{
                    position: 'absolute',
                    right: 0,
                    top: '110%',
                    width: '250px',
                    backgroundColor: 'var(--modal-bg)',
                    borderRadius: '0.75rem',
                    padding: '0.75rem',
                    boxShadow: 'var(--shadow-lg)',
                    border: '1px solid var(--border-subtle)',
                    zIndex: 200,
                  }}
                >
                  <div style={{ borderBottom: '1px solid var(--border-subtle)', paddingBottom: '0.5rem', marginBottom: '0.5rem' }}>
                    <p style={{ fontSize: '0.82rem', fontWeight: 700, color: 'var(--text-main)', margin: 0 }}>{user.name}</p>
                    <p style={{ fontSize: '0.72rem', color: 'var(--text-muted)', margin: 0 }}>{user.email}</p>
                    <span className={`badge ${isAdmin ? 'badge-critical' : 'badge-standard'}`} style={{ marginTop: '0.3rem', fontSize: '0.65rem' }}>
                      Role: {user.role.toUpperCase()}
                    </span>
                  </div>

                  <p style={{ fontSize: '0.7rem', color: 'var(--text-dim)', marginBottom: '0.35rem', fontWeight: 600 }}>
                    SWITCH TEST ROLE:
                  </p>
                  
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '0.35rem', marginBottom: '0.65rem' }}>
                    <button
                      className="btn btn-sm btn-ghost"
                      style={{ justifyContent: 'flex-start', fontSize: '0.78rem' }}
                      onClick={() => {
                        quickLogin('admin');
                        setShowUserMenu(false);
                      }}
                    >
                      <Sparkles size={14} color="var(--accent-red)" />
                      <span>System Admin (CRUD)</span>
                    </button>
                    <button
                      className="btn btn-sm btn-ghost"
                      style={{ justifyContent: 'flex-start', fontSize: '0.78rem' }}
                      onClick={() => {
                        quickLogin('user');
                        setShowUserMenu(false);
                      }}
                    >
                      <UserCheck size={14} color="var(--accent-blue)" />
                      <span>Citizen User (Speed Dial)</span>
                    </button>
                  </div>

                  <button
                    className="btn btn-sm btn-danger-ghost"
                    style={{ width: '100%', justifyContent: 'center' }}
                    onClick={() => {
                      logout();
                      setShowUserMenu(false);
                    }}
                  >
                    <LogOut size={14} />
                    <span>Sign Out</span>
                  </button>
                </div>
              )}
            </div>
          ) : (
            <button
              onClick={() => setActiveTab('login')}
              className={`btn ${activeTab === 'login' ? 'btn-primary' : 'btn-secondary'}`}
              style={{ padding: '0.45rem 0.85rem' }}
            >
              <LogIn size={16} />
              <span>Sign In / Register</span>
            </button>
          )}

        </div>
      </div>
    </header>
  );
};
