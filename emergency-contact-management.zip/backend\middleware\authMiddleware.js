const jwt = require('jsonwebtoken');
const { findUserById } = require('../services/dataService');

const verifyToken = async (req, res, next) => {
  try {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return res.status(401).json({
        success: false,
        message: 'Access Denied: Missing or invalid authorization token.',
      });
    }

    const token = authHeader.split(' ')[1];
    const secret = process.env.JWT_SECRET || 'emergency_jwt_secret_token_key_2026_super_secure';

    const decoded = jwt.verify(token, secret);
    const user = await findUserById(decoded.id);

    if (!user) {
      return res.status(401).json({
        success: false,
        message: 'Invalid session: User record no longer exists.',
      });
    }

    req.user = user;
    next();
  } catch (err) {
    return res.status(401).json({
      success: false,
      message: 'Authentication failed: ' + (err.name === 'TokenExpiredError' ? 'Token expired. Please login again.' : 'Invalid token signature.'),
    });
  }
};

const requireAdmin = (req, res, next) => {
  if (!req.user || req.user.role !== 'admin') {
    return res.status(403).json({
      success: false,
      message: 'Forbidden: Administrator privileges required for this emergency management operation.',
    });
  }
  next();
};

const optionalAuth = async (req, res, next) => {
  try {
    const authHeader = req.headers.authorization;
    if (authHeader && authHeader.startsWith('Bearer ')) {
      const token = authHeader.split(' ')[1];
      const secret = process.env.JWT_SECRET || 'emergency_jwt_secret_token_key_2026_super_secure';
      const decoded = jwt.verify(token, secret);
      const user = await findUserById(decoded.id);
      if (user) {
        req.user = user;
      }
    }
  } catch (err) {
    // Continue anonymously
  }
  next();
};

module.exports = {
  verifyToken,
  requireAdmin,
  optionalAuth,
};
